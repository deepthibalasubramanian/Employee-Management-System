import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import Modal from 'react-bootstrap/Modal';
import Add from './plus.png';
import Profile from './profile.png';

function AddEmployee() {
    const [show, setShow] = useState(false);
    const [pass, setPass] = useState('');
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [validated, setValidated] = useState(false);
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const handleSubmit = (event) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }

        setValidated(true);
    };
    return (
        <>
            <button type="button" onClick={handleShow} className="rounded-5 border-2">
                <img src={Add} className="p20" /> Add Employee
            </button>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Add Employee</h3>
                </Modal.Header>
                <Modal.Body >
                    {/* <input type="file"> </input> */}
                    <img src={Profile} className="p80"/>
                    <br /><br />
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                    <Row className="mb-3 justify-content-between">
                        <Form.Group as={Col} md="6" controlId="validationCustom01">
                            <Form.Label>First name</Form.Label>
                            <Form.Control
                                required
                                type="text"
                                placeholder="First name"
                            />
                            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                        </Form.Group>

                        <Form.Group as={Col} md="6" controlId="validationCustom02">
                            <Form.Label>Last name</Form.Label>
                            <Form.Control
                                required
                                type="text"
                                placeholder="Last name"
                            />
                            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                        </Form.Group>
                    </Row>
                    
                        <Form.Group md="4" controlId="validationCustomUsername">
                            <Form.Label>Email</Form.Label>
                            <InputGroup hasValidation>

                                <Form.Control
                                    type="email"
                                    placeholder="Email"
                                    required
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    // aria-describedby="inputGroupAppend"
                                />
                                {/* <InputGroup.Text id="inputGroupAppend">.com</InputGroup.Text> */}
                                <Form.Control.Feedback type="invalid">
                                    Please enter a username.
                                </Form.Control.Feedback>
                            </InputGroup>
                        </Form.Group>
                    
                    <br />
                    <Form.Group md="4" controlId="validationCustomPassword">
                        <Form.Label>Password</Form.Label>
                        <InputGroup hasValidation>

                            <Form.Control
                                type="password"
                                placeholder="Password"
                                required
                                onChange={(e) => setPass(e.target.value)}
                            />
                            
                            <Form.Control.Feedback type="invalid">
                                Please enter a password.
                            </Form.Control.Feedback>
                        </InputGroup>
                    </Form.Group>
                    <br />
                    
                    
                        <Form.Group md="6" controlId="validationCustom03">
                            <Form.Label>Phone Number</Form.Label>
                            <Form.Control
                                required
                                type="text"
                                placeholder="Phone Number"

                            />
                            <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                        </Form.Group>
                    
                    <br />

                </Form></Modal.Body>
                <Modal.Footer >

                    <button type="submit" onClick={handleSubmit} className="logoutc text-white rounded-5 border-0 p-2">&ensp;Create Employee&ensp;</button>

                </Modal.Footer>
            </Modal>
        </>
    );
}

export default AddEmployee;