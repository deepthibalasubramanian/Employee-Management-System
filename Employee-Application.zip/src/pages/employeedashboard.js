import React, {useEffect, useState} from 'react';
import ReactDOM from 'react-dom/client';
import '../assets/employeedstyle.css';
import Login from "./employeelogin";
import image from "../assets/profile.png"
import la from "../assets/la.png";
import lp from "../assets/lr.png";
import tl from "../assets/tl.png";
import rl from "../assets/rl.png";
import attendance from "../assets/attendance.png";
import { FaSignOutAlt } from "react-icons/fa";
import month from "../assets/month.png";
import week from "../assets/week.png";
import day from "../assets/day.png";
import '../css/bootstrap.min.css';
import Emppage from './emppage';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import LogoutRequest from './modal.js';
import TopBar from './topbar.js';
import SideBar from './sidebar.js';
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';
import ls from 'local-storage';
import API from "./base_services/service";
import Loading from './loading';

function Dashboard() {
    const data = ls.get('userDetails');
    const [dashboardInfo, setDashboardInfo] = useState("");
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        DashboardCount();
    }, [data.employees_id])
    const DashboardCount = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("employee_dashboard_count/condition", request).then((response) => {
            setDashboardInfo(response.data?.data[0])
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    return (
        <body>
            <TopBar data={data} />
            <SideBar />

            <div class="main">
                <h3>Dashboard</h3>
                {loading ? <Loading /> :
                <div class="sample d-flex flex-wrap ">
                    <div class="card h-25 border-0 mt-3 p-2 mx-2 mb-2 shadow rounded-0 " >
                        <h6>Attendance total</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.attendanceTotal}</h1>
                            <img src={attendance} width="50px" height="50px" />
                        </div>
                    </div>

                    <div class="card h-25 border-0 mt-3 p-2 mx-2 mb-2 shadow rounded-0" >
                        <h6>Attendance monthly</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.attendanceMonth}</h1>
                            <img src={month} width="50px" height="50px" />
                        </div>
                    </div>
                    <div class="card h-25 border-0 rounded-0 mt-3 p-2 mx-2 mb-2 shadow" >
                        <h6>Attendance weekly</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.attendanceWeek}</h1>
                            <img src={week} width="50px" height="50px" />
                        </div>
                    </div>
                    <div class="card h-25 border-0 rounded-0 mt-3 p-2 mx-2 mb-2 shadow" >
                        <h6>Total Leave Requests</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leaveCount}</h1>
                            <img src={tl} width="50px" height="50px" />
                        </div>
                    </div>
                    <div class="card h-25 border-0 rounded-0 mt-3 p-2 mx-2 mb-2 shadow" >
                        <h6>Leave Requests Pending</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leavePendingcount}</h1>
                            <img src={lp} width="50px" height="50px" />
                        </div>
                    </div>
                    <div class="card h-25 border-0 rounded-0 mt-3 p-2 mx-2 mb-2 shadow" >
                        <h6>Leave Requests Approved</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leaveApprovedcount}</h1>
                            <img src={la} width="50px" height="50px" />
                        </div>
                    </div>
                    <div class="card h-25 border-0 rounded-0 mt-3 p-2 mx-2 mb-2 shadow" >
                        <h6>Leave Requests Rejected</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leaveRejectedcount}</h1>
                            <img src={rl} width="50px" height="50px" />
                        </div>
                    </div>
                </div>}
            </div>

        </body>
    )
}

export default Dashboard;