// import logo from './logo.svg';
import './App.css';
import AppRouter from "./routes";
import "./overall.css"; 
import './css/bootstrap.min.css';
import './fontawesome/css/all.css';
function App() {
  return (
    <div className="App">
      <AppRouter />

    </div>
  );
}

export default App;
