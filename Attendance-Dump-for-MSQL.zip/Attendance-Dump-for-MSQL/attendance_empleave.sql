CREATE DATABASE  IF NOT EXISTS `attendance` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `attendance`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: attendance
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `empleave`
--

DROP TABLE IF EXISTS `empleave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `empleave` (
  `leave_id` int NOT NULL AUTO_INCREMENT,
  `employees_id` int NOT NULL,
  `type` varchar(45) NOT NULL,
  `reasons` varchar(245) NOT NULL,
  `from_date` varchar(100) NOT NULL,
  `to_date` varchar(100) NOT NULL,
  `active` int NOT NULL,
  `createdBy` int NOT NULL,
  `updatedBy` int DEFAULT NULL,
  `createdAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empleave`
--

LOCK TABLES `empleave` WRITE;
/*!40000 ALTER TABLE `empleave` DISABLE KEYS */;
INSERT INTO `empleave` VALUES (1,2,'sick','Not feeling well','2023-10-12','2023-10-12',2,2,2,'2023-10-11 07:48:46','2023-10-11 07:48:46'),(2,2,'Fever','Sufforing from fever','2023-10-12','2023-10-13',2,2,2,'2023-10-11 09:48:26','2023-10-11 09:48:26'),(3,1,'Personal','dfsygwresdg','2023-10-13','2023-10-14',1,1,1,'2023-10-13 09:33:28','2023-10-13 09:33:28'),(4,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',1,2,2,'2023-10-18 07:12:52','2023-10-18 07:12:52'),(5,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',1,2,2,'2023-10-18 07:13:37','2023-10-18 07:13:37'),(6,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',2,2,2,'2023-10-18 07:15:21','2023-10-18 07:15:21'),(7,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',4,2,2,'2023-10-18 07:15:56','2023-10-18 07:15:56'),(8,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',4,2,2,'2023-10-18 07:17:10','2023-10-18 07:17:10'),(9,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',1,2,2,'2023-10-18 07:18:38','2023-10-18 07:18:38'),(10,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',4,2,2,'2023-10-18 07:19:20','2023-10-18 07:19:20'),(11,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',1,2,2,'2023-10-18 07:21:50','2023-10-18 07:21:50'),(12,2,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',1,2,2,'2023-10-18 07:22:58','2023-10-18 07:22:58'),(13,1,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',4,1,1,'2023-10-18 07:31:13','2023-10-18 07:31:13'),(14,1,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',2,1,1,'2023-10-18 07:31:49','2023-10-18 07:31:49'),(15,1,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',1,1,1,'2023-10-18 07:33:34','2023-10-18 07:33:34'),(16,1,'Fever10','Sufforing from fever','2023-11-12','2023-11-15',2,1,1,'2023-10-18 13:40:58','2023-10-18 13:40:58');
/*!40000 ALTER TABLE `empleave` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-18 22:24:20
