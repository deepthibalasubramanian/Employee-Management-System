import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import './overall.css';
import './css/bootstrap.min.css';
import image from './profile.png';
import LeaveRequestView from './leavereqview';
import Sidebar from './sidebar';
import Topbar from './topbar';
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';
import API from '../src/baseServices/services'
import Loading from '../src/loading';
import Modal from 'react-bootstrap/Modal';
import Pagination from 'reactjs-hooks-pagination';

const pageLimit = 10;
function Leave() {
    const [leaveInfo, setLeavingInfo] = useState("");
    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        leaveList()
    }, [])

    const leaveList = () => {

        API.post("adminleavelist/condition").then((response) => {
            setLeavingInfo(response.data?.data)
            setTotalRecords(response.data.data?.length);
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    const [show, setShow] = useState(false);
    const [View, setView] = useState("");

    const handleClose = () => setShow(false);
    const handleShow = (data) => {
        setShow(true);
        leaveView(data)
    }

    const leaveView = (data) => {

        let request = {
            leave_id: data.leave_id
        }

        API.post("employeeleaveview/condition", request).then((response) => {
            setView(response.data?.data[0])
        })
    }

    const Approve = (data) => {

        let request = {
            leave_id: data.leave_id
        }

        API.post("adminleaveapprove/update", request).then((response) => {
            leaveList();
        })
    }

    const Reject = (data) => {

        let request = {
            leave_id: data.leave_id
        }

        API.post("adminleavedisapprove/update", request).then((response) => {
            leaveList();
        })
    }

    // ------------Search and filter----------------

    const [search, setSearch] = useState("");
    const [dropdown, setDropdown] = useState("");


    const Search = (drop, search) => {

        let request = {
            data: search,
            status: drop
        }

        API.post("leaverequestsearch/condition", request).then(response => {
            setCurrentPage(1)
            setLeavingInfo(response.data?.data)
            setTotalRecords(response.data.data?.length);
        });
    }

    const Onchange = (drop, search) => {
        Search(drop, search);
    }

    return (
        <body>
            <Topbar />
            <Sidebar />
            <div class="main">
                <div class="d-flex justify-content-between">
                    <h2>
                        Leave Requests
                    </h2>

                    <div className="p15 m-1 justify-content-between d-flex">
                        <div className="dropdown" id="dropdown">
                            <div className="cenitems d-flex">
                                <form className="text-white border-0 mainform">
                                    <div className="d-flex">
                                        <select onChange={(e) => { setDropdown(e.target.value); Onchange(e.target.value, search) }}>
                                            <option style={{ display: "none" }}>Select Status</option>
                                            <option value="">All</option>
                                            <option value="Pending">Pending</option>
                                            <option value="Approved">Approved</option>
                                            <option value="Rejected">Rejected</option>

                                        </select>
                                        &ensp;
                                        <input type="search" placeholder="Search.." id="myInput" onChange={(e) => { setSearch(e.target.value); Onchange(dropdown, e.target.value) }} />
                                    </div>
                                </form>
                            </div>
                        </div>
                        &ensp;
                    </div>
                </div>
                <br />
                {loading ? <Loading /> :
                    <table class="bg-white shadow wh100" >
                        <thead>
                            <tr class="ctext bb">
                                <th>
                                    ID
                                </th>
                                <th>
                                    Name
                                </th>
                                <th>
                                    Type
                                </th>
                                <th>
                                    Reason
                                </th>
                                <th>
                                    From
                                </th>
                                <th>
                                    To
                                </th>
                                <th>
                                    Applied on
                                </th>
                                <th>
                                    Status
                                </th>
                                <th>
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {leaveInfo?.length > 0 ? leaveInfo.sort((a, b) => b.admin_id - a.admin_id).slice(currentPage === 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage === 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                .map((leaveInfo, index) =>
                                    <tr className="bb" key={index}>
                                        <td>{leaveInfo.leave_id}</td>
                                        <td >{leaveInfo.employeename}</td>
                                        <td>{leaveInfo.type}</td>
                                        <td><button type="button" onClick={() => handleShow(leaveInfo)} className="logouta bg-secondary border-0">
                                            View
                                        </button></td>
                                        <td>{leaveInfo.from_date}</td>
                                        <td>{leaveInfo.to_date}</td>
                                        <td>{leaveInfo.createdDate}</td>
                                        {leaveInfo.active === 1 ?
                                            <td><span className="active-color">Approve</span></td> :
                                            leaveInfo.active === 4 ?
                                                <td><span className="inactive-color">Reject</span></td> :
                                                <td><span className="pending-color">Pending</span></td>
                                        }
                                        <td>
                                            {leaveInfo.active === 1 ?
                                                <button type="button" className="logouta bg-danger border-0" onClick={() => Reject(leaveInfo)}>
                                                    Reject
                                                </button> :
                                                <button type="button" className="logouta bg-success border-0" onClick={() => Approve(leaveInfo)}>
                                                    Approve
                                                </button>}
                                        </td>
                                    </tr>

                                ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}
                        </tbody>
                    </table>}
                <ul className="pagination">
                    <Pagination className=""
                        totalRecords={totalRecords}
                        pageLimit={pageLimit}
                        pageRangeDisplayed={1}
                        onChangePage={setCurrentPage}
                    />
                </ul>
            </div>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class='col-12 modal-title text-center'>
                        Reasons
                    </h3>
                </Modal.Header>
                <Modal.Body>{View.reasons}</Modal.Body>
                <Modal.Footer >
                    <button type="button" onClick={handleClose} className="logoutc text-white rounded-5 border-0 p-2">Close </button>
                </Modal.Footer>
            </Modal>
        </body>
    )
}
export default Leave; 