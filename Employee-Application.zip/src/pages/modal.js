import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import '../css/bootstrap.min.css';
import { useNavigate  } from 'react-router-dom';

function LogoutRequest() {
    const navigate = useNavigate();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    
    const LogOut = () => {
        navigate('/')
        localStorage.clear();
    }

    return (
        <>
            <button type="button" onClick={handleShow} className="logout text-white rounded-5 m-3 border-0">
                <i className="fa fa-sign-out" aria-hidden="true"></i>Logout
            </button>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class='col-12 modal-title text-center'>
                        Logout
                    </h3>
                </Modal.Header>
                <Modal.Body>
                    <p className='headingtype'>Do you want to logout?</p>
                    </Modal.Body>
                <Modal.Footer >
                    <button type="button" className="logoutc text-white rounded-5 border-0 pb-1"><a onClick={LogOut} class="links text-white">Yes</a> </button>
                    <button type="button" onClick={handleClose} className="logoutc text-white rounded-5 border-0 pb-1">No</button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default LogoutRequest;