import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import './css/bootstrap.min.css';
import { useNavigate  } from 'react-router-dom';
import { FaSignOutAlt } from 'react-icons/fa';

function LogoutRequest() {
    const navigate = useNavigate();
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const LogOut = () => {
        navigate('/')
        localStorage.clear();
    }

    return (
        <>
            <button type="button" onClick={handleShow} className="logout text-white rounded-5 m-3 border-0">
                <i className="fa fa-sign-out" aria-hidden="true"></i>Logout
            </button>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class='col-12 modal-title text-center'>
                        Logout
                    </h3>
                </Modal.Header>
                <Modal.Body>
                    <p className='headingtype'>Do you want to logout?</p>
                </Modal.Body>
                <Modal.Footer>
                    <div class="buttons-aln">
                        <button type="button" className="close-btn "><a onClick={LogOut} class="logouta">&ensp;Yes&ensp;</a> </button>&ensp;&ensp;
                        <button type="button" onClick={handleClose} className="submit-btn">&ensp;No&ensp;</button>
                    </div>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default LogoutRequest;