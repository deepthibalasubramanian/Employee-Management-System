import React, { useEffect, useState } from 'react';
import './overall.css';
// import Form from 'react-bootstrap/Form';
import eye from "./eye-solid.svg";
import edit from "./pen-to-square-solid.svg";
import './css/bootstrap.min.css';
import Sidebar from './sidebar';
import Topbar from './topbar';
import Pagination from 'reactjs-hooks-pagination';
import adduser from '../src/adduser.jpg'
import Modal from 'react-bootstrap/Modal';
import Add from './plus.png';
import API from '../src/baseServices/services'
import Loading from '../src/loading';
import ls from "local-storage";
// import FileBase64 from 'react-file-base64';

const pageLimit = 10
const Adminpage = () => {
    const data = ls.get('userDetails');
    const [adminList, setAdminList] = useState("");
    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    const [loadingPopup, setLoadingPopup] = useState(true);
    const [doc, setDoc] = useState("");
    const [type, setType] = useState("");
    const [showViewModal, setShowViewModal] = useState(false);
    const [showEditModal, setShowEditModal] = useState(false);
    const [viewRecord, setViewRecord] = useState(null);

    useEffect(() => {
        adminpage()
    }, [])

    const handleCloseViewModal = () => {
        setShowViewModal(false);
    };
    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setFNameEditError("");
        setLNameEditError("");
        setEmailEditError("");
        setPsswordEditError("");
        setPhoneEditError("");
    };
    const handleShowViewModal = (data) => {
        adminlist(data);
        setLoadingPopup(true);
        setShowViewModal(true);
    };
    const handleShowEditModal = (data) => {
        adminlist(data);
        setLoadingPopup(true);
        setShowEditModal(true);
    };

    const [adminId, setAdminId] = useState('');
    const [fNameEdit, setFNameEdit] = useState('');
    const [lNameEdit, setLNameEdit] = useState('');
    const [emailEdit, setEmailEdit] = useState('');
    const [passwordEdit, setPsswordEdit] = useState('');
    const [phoneEdit, setPhoneEdit] = useState('');
    const [active, setActive] = useState('no');
    const [fNameEditError, setFNameEditError] = useState('');
    const [lNameEditError, setLNameEditError] = useState('');
    const [emailEditError, setEmailEditError] = useState('');
    const [passwordEditError, setPsswordEditError] = useState('');
    const [phoneEditError, setPhoneEditError] = useState('');

    const adminlist = (data) => {
        let request = {
            admin_id: data.admin_id
        }
        API.post("adminview/condition", request)
            .then((response) => {
                // setTotalRecords(response.data?.data.length);
                const adminData = response.data?.data[0];
                setViewRecord(adminData);
                setAdminId(adminData.admin_id)
                setFNameEdit(adminData.first_name);
                setLNameEdit(adminData.last_name);
                setEmailEdit(adminData.email);
                setPsswordEdit(adminData.password);
                setPhoneEdit(adminData.phone_number);
                setActive(response.data?.data[0].active === 1 ? "yes" : "no")
                setTimeout(() => {
                    setLoadingPopup(false);
                }, 1000)
            });
    };

    const adminEdit = () => {
        setFNameEditError("");
        setLNameEditError("");
        setEmailEditError("");
        setPsswordEditError("");
        setPhoneEditError("");

        if (!fNameEdit) {
            setFNameEditError("First Name is required.")
            return;
        }
        else if (!lNameEdit) {
            setLNameEditError("Last Name is required.")
            return;
        }
        else if (!emailEdit) {
            setEmailEditError("Email is required.")
            return;
        }
        else if (emailEdit && !new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i).test(emailEdit)) {
            setEmailEditError('Must match the Email format');
            return;
        }
        else if (!passwordEdit) {
            setPsswordEditError("Password is required.")
            return;
        }
        else if (!phoneEdit) {
            setPhoneEditError("Phone Number is required.")
            return;
        }
        else if (phoneEdit.length < 10) {
            setPhoneEditError("PhoneNumber must have 10 digits");
            return;
        }
        else if (phoneEdit.length > 10) {
            setPhoneEditError("PhoneNumber accept only 10 digits");
            return;
        }

        let request = {
            admin_id: adminId,
            first_name: fNameEdit,
            last_name: lNameEdit,
            email: emailEdit,
            password: passwordEdit,
            phone_number: phoneEdit,
            admin_image: "",
            active: active === "yes" ? 1 : 4
        }

        API.post('adminedit/update', request).then((response) => {
            if (response.data?.success === true) {
                adminpage();
                handleCloseEditModal();
            }
        })

    }

    const adminpage = () => {

        API.post("adminlist/condition").then((response) => {
            setAdminList(response.data?.data)
            setTotalRecords(response.data?.data.length);
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    // ================================Add admin=====================================

    const [show, setShow] = useState(false);
    const handleClose = () => {
        setShow(false);
        setFNameError("");
        setLNameError("");
        setEmailError("");
        setPsswordError("");
        setPhoneError("");
    }
    const handleShow = () => setShow(true);
    const [fName, setFName] = useState('');
    const [lName, setLName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPssword] = useState('');
    const [phone, setPhone] = useState('');
    const [fNameError, setFNameError] = useState('');
    const [lNameError, setLNameError] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPsswordError] = useState('');
    const [phoneError, setPhoneError] = useState('');
    const [error, setError] = useState("");

    const handleSubmit = () => {
        setFNameError("");
        setLNameError("");
        setEmailError("");
        setPsswordError("");
        setPhoneError("");
        setError("");
        //setAdminId("");

        if (!fName) {
            setFNameError("First Name is required.")
            return;
        }
        else if (!lName) {
            setLNameError("Last Name is required.")
            return;
        }
        else if (!email) {
            setEmailError("Email is required.")
            return;
        }
        else if (email && !new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i).test(email)) {
            setEmailError('Must match the Email format');
            return;
        }
        else if (!password) {
            setPsswordError("Password is required.")
            return;
        }
        else if (!phone) {
            setPhoneError("Phone Number is required.")
            return;
        }
        else if (phone.length < 10) {
            setPhoneError("PhoneNumber must have 10 digits");
            return;
        }
        else if (phone.length > 10) {
            setPhoneError("PhoneNumber accept only 10 digits");
            return;
        }

        let request = {
            first_name: fName,
            last_name: lName,
            email: email,
            password: password,
            phone_number: phone,
            admin_image: "",
            createdBy: data.admin_id,
            updatedBy: data.admin_id
        }

        API.post('addadmin/add', request).then((response) => {
            if (response.data?.success === true) {
                adminpage();
                handleClose();
            } else {
                setError(response.data?.error.err)
            }
        })


    };
    // const getFname = (firstName) => {
    //     setSelectedFirstName(firstName); // Set the selected first name in state
    // };

    const getFiles = (file) => {
        console.log("================>", file.type)
        setType("")
        if (file.type.includes("jpg") || file.type.includes("jpeg") || file.type.includes("png")) {
            setDoc(file);
        } else {
            setType("0");
        }
    }


    // ------------Search and filter----------------

    const [search, setSearch] = useState("");
    const [dropdown, setDropdown] = useState("");


    const adminInfoSearch = (drop,search) => {

        let request = {
            data: search,
            status: drop
        }

        API.post("adminsearch/condition", request).then(response => {
            setCurrentPage(1)
            setAdminList(response.data?.data)
            setTotalRecords(response.data?.data.length);
        });
    }

    const Onchange = (drop,search) => {
        adminInfoSearch(drop,search);
    }


    return (
        <body>
            <Topbar />
            <Sidebar />
            <div className="main">
                <div className="d-flex justify-content-between">
                    <h2>Admins</h2>


                    <div className="p15 m-1 justify-content-between d-flex">
                        <div className="dropdown" id="dropdown">
                            <div className="cenitems d-flex">
                                <form className="text-white border-0 mainform">
                                    <div className="d-flex">
                                        <select onChange={(e) => {setDropdown(e.target.value);Onchange(e.target.value,search)}}>
                                            <option style={{ display: "none" }}>Select Status</option>
                                            <option value="">All</option>
                                            <option value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </select>
                                        &ensp;
                                        <input type="search" placeholder="Search.." id="myInput" 
                                            onChange={(e) => {setSearch(e.target.value);Onchange(dropdown,e.target.value)}} />
                                    </div>
                                </form>
                            </div>
                        </div>
                        &ensp;<button type="button" onClick={handleShow} className="rounded-5 border-2">
                            <img src={Add} alt="add admin" className="p20" /> Add Admin
                        </button>
                    </div>
                </div>
                <br />
                {loading ? <Loading /> :
                    <table className="bg-white shadow wh100" >
                        <thead>
                            <tr className="ctext bb" >
                                <th>ID</th>
                                <th>Name</th>
                                {/* <th>Image</th> */}
                                <th>Email</th>
                                <th>password</th>
                                <th>Phone Number</th>
                                <th>Created Date</th>
                                <th>Created By</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {adminList.length > 0 ? adminList.sort((a, b) => b.admin_id - a.admin_id).slice(currentPage === 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage === 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                .map((adminList, index) =>
                                    <tr className=" bb" key={index}>
                                        <td>{adminList.admin_id}</td>
                                        <td >{adminList.customerName}</td>
                                        {/* <td> <img className='admin-image' alt="" src={adminList.admin_image || adduser} /></td> */}
                                        <td>{adminList.email}</td>
                                        <td>{adminList.password}</td>
                                        <td>{adminList.phone_number}</td>
                                        <td>{adminList.createdDate}</td>
                                        <td>{adminList.CreatedBy}</td>
                                        {adminList.active === 1 ?
                                            <td><span className="active-color">Active</span></td> :
                                            <td><span className="inactive-color">Inactive</span></td>
                                        }
                                        <td>

                                            <button type="button" onClick={() => handleShowViewModal(adminList)} className="bg-white rounded-5 border-0 text-success">
                                                <img src={eye} alt="" className="p20" />
                                            </button>
                                            <button type="button" onClick={() => handleShowEditModal(adminList)} className="bg-white rounded-5 border-0 text-success">
                                                <img src={edit} alt="" className="p20" />
                                            </button>
                                        </td>
                                    </tr>

                                ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}
                        </tbody>
                    </table>}
                <ul className="pagination">
                    <Pagination className=""
                        totalRecords={totalRecords}
                        pageLimit={pageLimit}
                        pageRangeDisplayed={1}
                        onChangePage={setCurrentPage}
                    />
                </ul>
            </div>
            {/* ===========================Add Admin============================ */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Add Admin</h3>
                </Modal.Header>

                <Modal.Body>
                    {/* <div className="col-lg-2 buttons-aln">
                        <div className="col-lg-12 ">

                            <div className="user-upload-btn-wrapper">
                                {(image === "" || image == null || image === undefined) && doc === "" ? <img alt="" src={adduser} /> :
                                    doc === "" ? <img alt="" src={image} /> :
                                        <img alt="" src={doc.base64} />}
                                <span className="proCamera"></span>
                                <FileBase64 onDone={getFiles} className="hidden-image" type="hidden" />

                                {type === "0" ? <p className="text-danger">Upload only Image Format </p> : ""}
                            </div>
                        </div>
                    </div>
                    <br /> */}
                    <form>
                        <div className="row">
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">First Name</label>
                                <input type="text" className="form-control" onChange={(e) => setFName(e.target.value)} />
                                <p className="text-danger">{fNameError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Last Name</label>
                                <input type="text" className="form-control" onChange={(e) => setLName(e.target.value)} />
                                <p className="text-danger">{lNameError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Email</label>
                                <input type="text" className="form-control" onChange={(e) => setEmail(e.target.value)} />
                                <p className="text-danger">{emailError}</p>
                                <p className="text-danger">{error}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Password</label>
                                <input type="text" className="form-control" onChange={(e) => setPssword(e.target.value)} />
                                <p className="text-danger">{passwordError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Phone Number</label>
                                <input type="text" className="form-control" onChange={(e) => setPhone(e.target.value)} />
                                <p className="text-danger">{phoneError}</p>
                            </div>
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer >
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleClose} className="close-btn">Close</button>&ensp;
                        <button type="submit" onClick={handleSubmit} className="submit-btn ">Submit</button>
                    </div>
                </Modal.Footer>
            </Modal>

            {/* ===========================View Admin Details============================ */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={showViewModal} onHide={handleCloseViewModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Admin View</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>
                        <form>
                            <div class="row">
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Admin Id</label>
                                    <input type="text" className="form-control" value={viewRecord.admin_id} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">First Name</label>
                                    <input type="text" className="form-control" value={viewRecord.first_name} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Last Name</label>
                                    <input type="text" className="form-control" value={viewRecord.last_name} disabled />

                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Email</label>
                                    <input type="text" className="form-control" value={viewRecord.email} disabled />

                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Password</label>
                                    <input type="text" className="form-control" value={viewRecord.password} disabled />

                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Phone Number</label>
                                    <input type="text" className="form-control" value={viewRecord.phone_number} disabled />

                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="email" className="col-form-label">Status</label>
                                    <div className="form-check form-switch">
                                        <input className="form-check-input me-2" type="checkbox" id="flexSwitchCheckChecked" checked={active === "yes" ? true : false} disabled />
                                    </div>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseViewModal} className="close-btn">Close</button>
                    </div>
                </Modal.Footer>
            </Modal>

            {/* ====================================Edit Admin Records============================= */}

            <Modal size="wrapper modal-dialog-centered modal-lg" show={showEditModal} onHide={handleCloseEditModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Admin Edit</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>

                        <form>

                            <div class="row">
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Admin Id</h5></label>
                                    <input className="form-control" value={adminId} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>First Name</h5></label>
                                    <input className="form-control" value={fNameEdit} onChange={(e) => setFNameEdit(e.target.value)} />
                                    <p className="text-danger">{fNameEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Last Name</h5></label>
                                    <input className="form-control" value={lNameEdit} onChange={(e) => setLNameEdit(e.target.value)} />
                                    <p className="text-danger">{lNameEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Email</h5></label>
                                    <input className="form-control" value={emailEdit} onChange={(e) => setEmailEdit(e.target.value)} />
                                    <p className="text-danger">{emailEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Password</h5></label>
                                    <input className="form-control" value={passwordEdit} onChange={(e) => setPsswordEdit(e.target.value)} />
                                    <p className="text-danger">{passwordEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Phone Number</h5></label>
                                    <input className="form-control" value={phoneEdit} onChange={(e) => setPhoneEdit(e.target.value)} />
                                    <p className="text-danger">{phoneEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="email" className="col-form-label">Status</label>
                                    <div className="form-check form-switch">
                                        <input className="form-check-input me-2" type="checkbox" id="flexSwitchCheckChecked" value={active === "no" ? "yes" : "no"} checked={active == "yes" ? true : false} onChange={(e) => setActive(e.target.value)} />
                                    </div>
                                </div>
                            </div>

                        </form>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseEditModal} className="close-btn">Close</button>&ensp;
                        <button type="submit" onClick={adminEdit} className="submit-btn ">Submit</button>
                    </div>
                </Modal.Footer>
            </Modal>
        </body>
    )
}

export default Adminpage;
