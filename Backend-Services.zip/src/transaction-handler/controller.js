const map = require("./map");
const _ = require("lodash");
const { getMetadataConfig } = require("../../shared/db/metadata");
var admin = require("firebase-admin");
var CryptoJS = require("crypto-js");
var key = CryptoJS.enc.Hex.parse("0123456789abcdef");
var iv = CryptoJS.enc.Hex.parse("fedcba9876543210");
var generator = require('generate-password');

module.exports = (function () {
    return {
        healthcheck(req, res) {
            map.healthcheck(req, res);
        },
        getAll(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;
            const { where, customizeQuery } = req.query;
            const { type, name, whereClause, baseQuery, order } = getMetadataConfig(model, "list")["tableInfo"];
            let query;
            console.log(customizeQuery, "customizeQuery::::::");
            if (customizeQuery) {
                query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
            } else {
                const base = `${baseQuery}`;
                query = sequelize.query(base, { type: sequelize.QueryTypes.SELECT });
            }
            query.then(
                (data) => map.getAll(req, res, data),
                (err) => map.error(req, res, err)
            );
        },
        update(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;

            if (model === "adminedit") {
                const updatestatus = `update admin set
        first_name = '${req.body.first_name}', last_name = '${req.body.last_name}',
        email = '${req.body.email}', phone_number = '${req.body.phone_number}',
        admin_image = '${req.body.admin_image}',
        password = '${req.body.password}', active = '${req.body.active}'
        where admin_id = '${req.body.admin_id}'`;
                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(
                    data => map.put(req, res, data),
                    err => map.error(req, res, err),
                );
            }

            else if (model === "employeeedit") {
                const updatestatus = `update employees set
      first_name = '${req.body.first_name}', last_name = '${req.body.last_name}',
      email = '${req.body.email}', phone_number = '${req.body.phone_number}',
       department = '${req.body.department}',
      password = '${req.body.password}', active = '${req.body.active}'
      where employees_id = '${req.body.employees_id}'`;
                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(
                    data => map.put(req, res, data),
                    err => map.error(req, res, err),
                );
            }
            else if (model === "leaveEdit") {
                const updatestatus = `update empleave set
    from_date = '${req.body.from_date}', to_date = '${req.body.to_date}',
    type = '${req.body.type}', reasons = '${req.body.reasons}'
    where leave_id = '${req.body.leave_id}'`;
                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(
                    data => map.put(req, res, data),
                    err => map.error(req, res, err),
                );
            }

            else if (model === "adminleaveapproved") {
                const updatestatus = `update empleave set
            active = 1
            where leave_id = '${req.body.leave_id}'`;

                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(data => {
                    const customizeQuery = `select *,
          DATE_FORMAT(e.createdAt, '%d/%m/%Y') as createdDate,
          concat(e.first_name," ",e.last_name) as employeeName
          from employees e where e.active=1 and e.employees_id = ${req.body.employees_id} order by e.employees_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.put(req, res, data),
                        err => map.error(req, res, err),
                    );

                })
                    .catch(err => {
                        map.error(req, res, err);
                    });
            }

            else if (model === "adminleavedisapprove") {
                const updatestatus = `update empleave set
            active = 4
            where leave_id = '${req.body.leave_id}'`;

                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(data => {
                    const customizeQuery = `select *,
          DATE_FORMAT(e.createdAt, '%d/%m/%Y') as createdDate,
          concat(e.first_name," ",e.last_name) as employeeName
          from employees e where e.active=4 and e.employees_id = ${req.body.employees_id} order by e.employees_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.put(req, res, data),
                        err => map.error(req, res, err),
                    );

                })
                    .catch(err => {
                        map.error(req, res, err);
                    });
            }
            else if (model === "loginAdd") {
                const updatestatus = `update employees set
                in_out = 1
    where employees_id = '${req.body.employees_id}'`;
                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(
                    data => map.put(req, res, data),
                    err => map.error(req, res, err),
                );
            }

            else if (model === "logoutAdd") {
                const updatestatus = `update employees set
                in_out = 4
    where employees_id = '${req.body.employees_id}'`;
                let query = sequelize.query(updatestatus, { type: sequelize.QueryTypes.update });
                query.then(
                    data => map.put(req, res, data),
                    err => map.error(req, res, err),
                );
            }

            else if (model === "addemployeesouttime") {
                try {
                    let ts = Date.now();
                    let d = new Date();
                    let date = ("0" + d.getDate()).slice(-2);
                    let month = ("0" + (d.getMonth() + 1)).slice(-2);
                    let year = d.getFullYear();
                    let hours = d.getHours();
                    let minutes = d.getMinutes();
                    let seconds = d.getSeconds();
                    let time = hours + ':' + minutes + ':' + seconds;
                    let datetime = d.toISOString().slice(0, 19).replace("T", " ");

                    const selectQuery = `
                        SELECT * FROM attendance
                        WHERE employees_id = '${req.body.employees_id}'
                        ORDER BY attendance_id DESC
                        LIMIT 1`;

                    sequelize.query(selectQuery, { type: sequelize.QueryTypes.SELECT })
                        .then(data1 => {
                            if (data1.length > 0) {
                                const attendanceId = data1[0].attendance_id;

                                const updateStatusQuery = `
                                    UPDATE attendance
                                    SET out_time = '${time}'
                                    WHERE attendance_id = '${attendanceId}'`;

                                sequelize.query(updateStatusQuery, { type: sequelize.QueryTypes.UPDATE })
                                    .then(data => map.put(req, res, data))
                                    .catch(err => map.error(req, res, err));
                            } else {
                                map.error(req, res, { message: "No attendance records found for the employee." });
                            }
                        })
                        .catch(err => map.error(req, res, err));
                } catch (error) {
                    map.error(req, res, { err: error });
                }
            }


        },

        condition(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;

            if (model === "adminlist") {
                try {
                    const customizeQuery = `select *,
            DATE_FORMAT(createdAt, '%d/%m/%Y') as createdDate,
            concat(first_name," ",last_name) as customerName,
            (SELECT concat(first_name," ",last_name)from admin where createdBy = admin_id) as CreatedBy
            from admin where active in (1,4) order by admin_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employeeslist") {
                try {
                    const customizeQuery = `select *,
          DATE_FORMAT(createdAt, '%d/%m/%Y') as createdDate,
          (SELECT concat(first_name," ",last_name)from admin where e.createdBy = admin_id) as CreatedBy,
          concat(first_name," ",last_name) as employeeName
          from employees e where active in (1,4) order by employees_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "adminleavelist") {
                try {
                    const customizeQuery = `select el.*,
        DATE_FORMAT(el.createdAt, '%d/%m/%Y') as createdDate,
        (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = el.employees_id) as employeename   
        from empleave el
        join employees em on el.employees_id = em.employees_id
        where el.active in (1,2,4) order by el.leave_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employeeleavelist") {
                try {
                    const customizeQuery = `select *,
        DATE_FORMAT(el.createdAt, '%d/%m/%Y') as createdDate,
        (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = el.employees_id) as employeename   
        from empleave el
        where employees_id = ${req.body.employees_id} and el.active in (1,2,4) order by leave_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "admin_atenList") {
                try {
                    const customizeQuery = `select *, DATE_FORMAT(at.createdAt, '%d/%m/%y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = at.employees_id) as employeename  
                   from attendance at
                   join employees em on at.employees_id = em.employees_id
                   where at.active in (1,4) order by at.attendance_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "admin_atenView") {
                try {
                    const customizeQuery = `select *, DATE_FORMAT(at.createdAt, '%d/%m/%y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = at.employees_id) as employeename  
                   from attendance at
                   join employees em on at.employees_id = em.employees_id
                   where at.active in (1,4) and at.attendance_id = ${req.body.attendance_id} order by at.attendance_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "emp_atenList") {
                try {
                    const customizeQuery = `select *, DATE_FORMAT(at.createdAt, '%d/%m/%y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = at.employees_id) as employeename  
                   from attendance at
                   join employees em on at.employees_id = em.employees_id
                   where at.active in (1,4) and at.employees_id = ${req.body.employees_id} order by at.attendance_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "adminview") {
                try {
                    const customizeQuery = `select *,
        DATE_FORMAT(createdAt, '%d/%m/%Y') as createdDate,
        (SELECT concat(first_name," ",last_name)from admin where createdBy = admin_id) as CreatedBy,
        concat(first_name," ",last_name) as adminName
        from admin where admin_id = ${req.body.admin_id} and active in (1,4)`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employeeview") {
                try {
                    const customizeQuery = `select *,
      DATE_FORMAT(createdAt, '%d/%m/%Y') as createdDate,
      (SELECT concat(first_name," ",last_name)from admin where e.createdBy = admin_id) as CreatedBy,
      concat(first_name," ",last_name) as employeeName
      from employees e where employees_id = ${req.body.employees_id} and active in (1,4)`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employeeleaveview") {
                try {
                    const customizeQuery = `select *,
        DATE_FORMAT(el.createdAt, '%d/%m/%Y') as createdDate,
        (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = el.employees_id) as employeename   
        from empleave el
        where leave_id = ${req.body.leave_id} and el.active in (1,2,4) order by leave_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employee_atenList") {
                try {
                    const customizeQuery = `select *, DATE_FORMAT(at.createdAt, '%d/%m/%y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = at.employees_id) as employeename  
                   from attendance at
                   join employees em on at.employees_id = em.employees_id
                   where at.employees_id = ${req.body.employees_id} and at.active in (1,4) order by at.attendance_id desc`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "adminsearch") {
                try {
                    let customizeQuery = `select *,
                    DATE_FORMAT(createdAt, '%d/%m/%Y') as createdDate,
                    concat(first_name," ",last_name) as customerName,
                    (SELECT concat(first_name," ",last_name)from admin where createdBy = admin_id) as CreatedBy
                    from admin where active in (1,4)`
                    if (req.body.data !== "") {
                        customizeQuery = customizeQuery + " and (concat(first_name,' ',last_name) regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or email regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or admin_id regexp '" + req.body.data + "')"
                    }
                    if (req.body.status !== "") {
                        if (req.body.status === "Active") {
                            customizeQuery = customizeQuery + " and active = 1 ";
                        }

                        if (req.body.status === "Inactive") {
                            customizeQuery = customizeQuery + " and active = 4 ";
                        }
                    }

                    customizeQuery = customizeQuery + ` order by admin_id desc`
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );

                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employeesearch") {
                try {
                    let customizeQuery = `select *,
                    DATE_FORMAT(createdAt, '%d/%m/%Y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from admin where e.createdBy = admin_id) as CreatedBy,
                    concat(first_name," ",last_name) as employeeName
                    from employees e where active in (1,4)`
                    if (req.body.data !== "") {
                        customizeQuery = customizeQuery + " and (concat(first_name,' ',last_name) regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or email regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or department regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or employees_id regexp '" + req.body.data + "')"
                    }
                    if (req.body.status !== "") {
                        if (req.body.status === "Active") {
                            customizeQuery = customizeQuery + " and active = 1 ";
                        }

                        if (req.body.status === "Inactive") {
                            customizeQuery = customizeQuery + " and active = 4 ";
                        }
                    }

                    customizeQuery = customizeQuery + ` order by employees_id desc`
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );

                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }
            else if (model === "attendancesearch") {
                try {
                    let customizeQuery = `select *, DATE_FORMAT(at.createdAt, '%d/%m/%y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = at.employees_id) as employeename  
                   from attendance at
                   join employees em on at.employees_id = em.employees_id
                   where at.active in (1,4)`

                    if (req.body.data !== "") {
                        customizeQuery = customizeQuery + " and concat(e.first_name,' ',e.last_name) regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or e.employees_id regexp '" + req.body.data + "'"
                    }

                    if (req.body.status !== "") {
                        if (req.body.status === "Active") {
                            customizeQuery = customizeQuery + " and active = 1 ";
                        }

                        if (req.body.status === "Inactive") {
                            customizeQuery = customizeQuery + " and active = 4 ";
                        }
                    }

                    customizeQuery = customizeQuery + " order by attendance_id desc";
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });

                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );

                } catch (error) {
                    map.error(req, res, { err: error });
                }
            }


            // else if (model === "leaverequestsearch") {
            //     try {
            //         let customizeQuery = `select *,
            //         DATE_FORMAT(el.createdAt, '%d/%m/%Y') as createdDate,
            //         (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = el.employees_id) as employeename   
            //         from empleave el
            //         where el.active in (1,2,4)`
            //         if (req.body.data !== "") {
            //             customizeQuery = customizeQuery + " and (concat(first_name,' ',last_name) regexp '" + req.body.data + "'"
            //             customizeQuery = customizeQuery + " or employees_id regexp '" + req.body.data + "')"
            //         }
            //         if (req.body.status !== "") {
            //             if (req.body.status === "Active") {
            //                 customizeQuery = customizeQuery + " and active = 1 ";
            //             }

            //             if (req.body.status === "Pending") {
            //                 customizeQuery = customizeQuery + " and active = 2 ";
            //             }

            //             if (req.body.status === "Inactive") {
            //                 customizeQuery = customizeQuery + " and active = 4 ";
            //             }
            //         }

            //         customizeQuery = customizeQuery + ` order by e.employees_id desc`
            //         let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
            //         query.then(
            //             data => map.getAll(req, res, data),
            //             err => map.error(req, res, err),
            //         );

            //     } catch (error) {
            //         map.error(req, res, { err: error })
            //     }
            // }

            else if (model === "leaverequestsearch") {
                try {
                    let customizeQuery = `select el.*,
                    DATE_FORMAT(el.createdAt, '%d/%m/%Y') as createdDate,
                    (SELECT concat(first_name," ",last_name)from employees e where e.employees_id = el.employees_id) as employeename   
                    from empleave el
                    join employees em on el.employees_id = em.employees_id
                    where el.active in (1,2,4)`
                    if (req.body.data !== "") {
                        customizeQuery = customizeQuery + " and (concat(em.first_name,' ',em.last_name) regexp '" + req.body.data + "'"
                        customizeQuery = customizeQuery + " or el.leave_id regexp '" + req.body.data + "')"
                    }
                    if (req.body.status !== "") {
                        if (req.body.status === "Approved") {
                            customizeQuery = customizeQuery + " and el.active = 1 ";
                        }

                        if (req.body.status === "Pending") {
                            customizeQuery = customizeQuery + " and el.active = 2 ";
                        }

                        if (req.body.status === "Rejected") {
                            customizeQuery = customizeQuery + " and el.active = 4 ";
                        }
                    }

                    customizeQuery = customizeQuery + ` order by el.leave_id desc`
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );

                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }
            else if (model === "admin_dashboard_count") {
                try {
                    const customizeQuery = `SELECT 
                    (SELECT COUNT(*) FROM admin) AS adminCount,
                   (SELECT COUNT(*) FROM employees) AS employeesCount,
                   (SELECT COUNT(*) FROM attendance) AS attendanceCount,
                   (SELECT COUNT(*) FROM empleave WHERE active IN (1, 2, 4)) AS leaveCount,
                   (SELECT COUNT(*) FROM empleave WHERE active = 1) AS leaveApprovedcount,
                   (SELECT COUNT(*) FROM empleave WHERE active = 2) AS leavePendingcount,
                   (SELECT COUNT(*) FROM empleave WHERE active = 4) AS leaveRejectedcount`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }
            else if (model === "employee_dashboard_count") {
                try {
                    const customizeQuery = `SELECT 
                    (SELECT COUNT(*) FROM empleave WHERE employees_id = ${req.body.employees_id} and active IN (1, 2, 4)) AS leaveCount,
                    (SELECT COUNT(*) FROM empleave WHERE employees_id = ${req.body.employees_id}  and active = 1) AS leaveApprovedcount,
                    (SELECT COUNT(*) FROM empleave WHERE employees_id = ${req.body.employees_id} and active = 2) AS leavePendingcount,
                    (SELECT COUNT(*) FROM empleave WHERE employees_id = ${req.body.employees_id} and active = 4) AS leaveRejectedcount,
                    (SELECT COUNT(*) FROM attendance WHERE employees_id = ${req.body.employees_id} and active = 1) AS attendanceTotal,
                    (select count(*) from attendance Where employees_id = ${req.body.employees_id} and createdAt between date_sub(now(),INTERVAL 1 WEEK) and now() ) as attendanceWeek,
                    (select count(*) from attendance Where employees_id = ${req.body.employees_id} and createdAt between date_sub(now(),INTERVAL 1 MONTH) and now() ) as attendanceMonth`
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => map.getAll(req, res, data),
                        err => map.error(req, res, err),
                    );
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }
        },
        login(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;

            if (model === "adminlogin") {
                try {
                    let Password = CryptoJS.AES.encrypt(req.body.Password, key, { iv: iv });
                    const costomizeQuery = `SELECT * from admin where email= '${req.body.email}' and active=1 `
                    let query = sequelize.query(costomizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        login => {
                            if (login.length !== 0) {
                                console.log("===>>>", login[0].Password);
                                if (login[0].Password === req.body.Password) {
                                    let i;
                                    Number(i) + 1;
                                    var datavalue = generator.generate({
                                        length: 24,
                                        number: true,
                                        uppercase: true,
                                    });
                                    query.then(
                                        data => map.put(req, res, data),
                                        err => map.error(req, res, err)
                                    );
                                } else {
                                    map.error(req, res, { mailError: 'Incorrect Password' })
                                }
                            } else {
                                map.error(req, res, { mailError: 'Email not registered' })
                            }
                        },
                        err => map.error(req, res, err),
                    );
                } catch (err) {
                    map.error(req, res, { error: err })
                }
            }
            else if (model === "employeelogin") {
                try {
                    let password = CryptoJS.AES.encrypt(req.body.password, key, { iv: iv });
                    const costomizeQuery = `SELECT * from employees where email= '${req.body.email}' and active=1 `
                    let query = sequelize.query(costomizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        login => {
                            if (login.length !== 0) {
                                console.log("===>>>", login[0].password);
                                if (login[0].password === req.body.password) {
                                    let i;
                                    Number(i) + 1;
                                    var datavalue = generator.generate({
                                        length: 24,
                                        number: true,
                                        uppercase: true,
                                    });
                                    query.then(
                                        data => map.put(req, res, data),
                                        err => map.error(req, res, err)
                                    );
                                } else {
                                    map.error(req, res, { mailError: 'Incorrect Password' })
                                }
                            } else {
                                map.error(req, res, { mailError: 'Email not registered' })
                            }
                        },
                        err => map.error(req, res, err),
                    );
                } catch (err) {
                    map.error(req, res, { error: err })
                }
            }
        },

        get(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;
            const { where, customizeQuery } = req.query;
            const { type, name, whereClause, baseQuery, order } = getMetadataConfig(model, "list")["tableInfo"];
            let query;
            if (customizeQuery) {
                query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
            } else {
                const base = `${baseQuery} where ${whereClause}`;
                query = sequelize.query(base, { type: sequelize.QueryTypes.SELECT });
            }
            query.then(
                (data) => map.get(req, res, data),
                (err) => map.error(req, res, err)
            );
        },

        post(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;
            let emailValue = 0;

            if (model === "addadmin") {
                try {
                    const customizeQuery = `SELECT * from admin where email = '${req.body.email}'`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => {
                            console.log("===data=>", data);
                            email = data.length;
                            if (email === 0) {

                                const obj = {
                                    first_name: req.body.first_name,
                                    last_name: req.body.last_name,
                                    email: req.body.email,
                                    password: req.body.password,
                                    phone_number: req.body.phone_number,
                                    admin_image: req.body.admin_image,
                                    active: 1,
                                    createdBy: req.body.createdBy,
                                    updatedBy: req.body.updatedBy
                                }
                                console.log("=>", obj);
                                _.get(global.components.dbConnections, 'admin', '').create(obj).then(
                                    data => map.post(req, res, data),
                                    err => map.error(req, res, err)
                                )
                            } else {
                                map.error(req, res, { err: 'Email Already Existed' });
                            }
                        }
                    )
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }
            else if (model === "admin-image-add") {
                console.log("==========>>>>>>>>>>", model);
                try {
                    const s3 = new aws.S3();
                    let ts = Date.now();
                    if (req.body.admin_image !== "") {
                        let basevalue = req.body.admin_image[0].base64.split('base64,');
                        const base64Data = new Buffer.from(basevalue[1], 'base64');
                        const params = {
                            Bucket: bucket,
                            Key: ts + "_",
                            Body: base64Data,
                            ContentType: 'image/jpeg',
                            ContentEncoding: 'base64',
                            ACL: 'public-read'
                        };
                        new Promise((resolve, reject) => {
                            s3.upload(params, (err, data) => err == null ? resolve(data) : reject(err));
                            var attachment = s3url + ts + "_";
                            map.post(req, res, attachment)
                        })
                    } else {
                        map.error(req, res, { err: `Invalid Image ` })
                    }
                } catch (ex) {
                    map.error(req, res, { err: ex })
                }
            }

            else if (model === "addemployees") {
                try {
                    const customizeQuery = `SELECT * from employees where email = '${req.body.email}'`;
                    let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                    query.then(
                        data => {
                            console.log("===data=>", data);
                            email = data.length;
                            if (email === 0) {

                                const obj = {
                                    first_name: req.body.first_name,
                                    last_name: req.body.last_name,
                                    email: req.body.email,
                                    password: req.body.password,
                                    phone_number: req.body.phone_number,
                                    employee_image: req.body.employee_image,
                                    department: req.body.department,
                                    active: 1,
                                    createdBy: req.body.createdBy,
                                    updatedBy: req.body.updatedBy
                                }
                                console.log("=>", obj);
                                _.get(global.components.dbConnections, 'employees', '').create(obj).then(
                                    data => map.post(req, res, data),
                                    err => map.error(req, res, err)
                                )
                            } else {
                                map.error(req, res, { err: 'Email Already Existed' });
                            }
                        }
                    )
                } catch (error) {
                    map.error(req, res, { err: error })
                }
            }

            else if (model === "employee-image-add") {
                console.log("==========>>>>>>>>>>", model);
                try {
                    const s3 = new aws.S3();
                    let ts = Date.now();
                    if (req.body.employee_image !== "") {
                        let basevalue = req.body.employee_image[0].base64.split('base64,');
                        const base64Data = new Buffer.from(basevalue[1], 'base64');
                        const params = {
                            Bucket: bucket,
                            Key: ts + "_",
                            Body: base64Data,
                            ContentType: 'image/jpeg',
                            ContentEncoding: 'base64',
                            ACL: 'public-read'
                        };
                        new Promise((resolve, reject) => {
                            s3.upload(params, (err, data) => err == null ? resolve(data) : reject(err));
                            var attachment = s3url + ts + "_";
                            map.post(req, res, attachment)
                        })
                    } else {
                        map.error(req, res, { err: `Invalid Image ` })
                    }
                } catch (ex) {
                    map.error(req, res, { err: ex })
                }
            }

            // else if (model === "addemployeesleave") {
            //     const customizeQuery = `SELECT * FROM empleave where employees_id ='${req.body.employees_id}'`;

            //     let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });

            //     query.then(data => {
            //         const obj = {
            //             employees_id: req.body.employees_id,
            //             type: req.body.type,
            //             reasons: req.body.reasons,
            //             from_date: req.body.from_date,
            //             to_date: req.body.to_date,
            //             active: 2,
            //             createdBy: req.body.createdBy,
            //             updatedBy: req.body.updatedBy,
            //         };
            //         _.get(global.components.dbConnections, 'empleave', '').create(obj).then(
            //             data => map.post(req, res, data),
            //             err => map.error(req, res, err)
            //         )
            //     }).catch(err => {
            //         map.error(req, res, err);
            //     });
            // }

            else if (model === "addemployeesleave") {
                const obj = {
                    employees_id: req.body.employees_id,
                    type: req.body.type,
                    reasons: req.body.reasons,
                    from_date: req.body.from_date,
                    to_date: req.body.to_date,
                    active: 2,
                    createdBy: req.body.createdBy,
                    updatedBy: req.body.updatedBy,
                };

                _.get(global.components.dbConnections, 'empleave', '').create(obj)
                    .then(data => {
                        const customizeQuery = `select *,
          DATE_FORMAT(e.createdAt, '%d/%m/%Y') as createdDate,
          concat(e.first_name," ",e.last_name) as employeeName
          from employees e where e.active=1 and e.employees_id = ${req.body.employees_id} order by e.employees_id desc`;
                        let query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
                        query.then(
                            data => map.post(req, res, data),
                            err => map.error(req, res, err)
                        )
                    })
            }

            else if (model === "addemployeesintime") {
                let ts = Date.now();
                let d = new Date();
                let date = ("0" + d.getDate()).slice(-2);
                let month = ("0" + (d.getMonth() + 1)).slice(-2);
                let year = d.getFullYear();
                let hours = d.getHours();
                let minutes = d.getMinutes();
                let seconds = d.getSeconds();
                let milliseconds = d.getMilliseconds();
                let time = hours + ':' + minutes + ':' + seconds;
                let datetime = year + "-" + month + "-" + date + ' ' + hours + ':' + minutes + ':' + seconds;

                const obj = {
                    employees_id: req.body.employees_id,
                    in_time: time,
                    active: 1,
                };
                _.get(global.components.dbConnections, 'attendance', '').create(obj).then(
                    data => map.post(req, res, data,),
                    err => map.error(req, res, err)
                )
            }

        },

        put(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;
            const { id } = req.params;
            const { type, name, whereClause, baseQuery, order } = getMetadataConfig(model, "list")["tableInfo"];
            _.get(global.components.dbConnections, model, "")
                .update(req.body, {
                    where: {
                        [whereClause]: id,
                    },
                })
                .then(
                    (data) => map.put(req, res, data),
                    (err) => map.error(req, res, err)
                );
        },

        delete(req, res) {
            const model = req.originalUrl.split("/")[3];
            const { sequelize } = global.components;
            const { where, customizeQuery } = req.query;
            const { type, name, whereClause, baseQuery, order } = getMetadataConfig(model, "list")["tableInfo"];
            let query;
            console.log(customizeQuery, "customizeQuery::::::", req.query, req.params);
            query = sequelize.query(customizeQuery, { type: sequelize.QueryTypes.SELECT });
            query.then(
                (data) => {
                    if (data.length > 0) {
                        _.get(global.components.dbConnections, model, "")
                            .update(
                                { Isactive: "InActive" },
                                {
                                    where: {
                                        [whereClause]: req.params.id,
                                    },
                                }
                            )
                            .then((data) => map.delete(req, res, data));
                    }
                },
                (err) => map.error(req, res, err)
            );
        },
    };
})();
