import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import React from "react";
import Login from "../pages/employeelogin";
import Dashboard from "../pages/employeedashboard";
import Emppage from "../pages/emppage";
import Profile from "../pages/emprofile";
import Attend from "../pages/attend";
// import '../src/assets/css/style.css';
// import '../src/assets/vendor/bootstrap/css/bootstrap.min.css';


const  AppRouter = () => {
  return (
    <div>
          <Router>
            <Routes>
              <Route exact path="/" element={<Login />} />
              <Route path="/employeedashboard" element={<Dashboard />} />
              <Route path="/emppage" element={<Emppage />} />
              <Route path="/empprofile" element={<Profile />} />
              <Route path="/attend" element={< Attend/>} />
              
            </Routes>
        </Router>
  
    </div>
  );
}
export default AppRouter;

