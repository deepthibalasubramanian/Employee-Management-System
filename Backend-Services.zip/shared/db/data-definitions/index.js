

module.exports = function () {
    return {
        
    };
}();