import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import './overall.css';
import './css/bootstrap.min.css';
import image from './profile.png';
import eye from './eye-solid.svg';
import Sidebar from './sidebar';
import Topbar from './topbar';
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';
import Pagination from 'reactjs-hooks-pagination';
import Modal from 'react-bootstrap/Modal';
import API from '../src/baseServices/services'
import Loading from '../src/loading';

const pageLimit = 5;

function Attendance() {
    // const [attenlist,setattenlist] = useState("");
    const [viewRecord, setViewRecord] = useState(null);
    const [showViewModal, setShowViewModal] = useState(false);
    const [attendanceList, setAttendanceList] = useState("");
    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    const [loadingPopup, setLoadingPopup] = useState(true);
    const handleShowViewModal = (data) => {
        admin_atenList(data);
        setLoadingPopup(true);
        setShowViewModal(true);
    };
    const handleCloseViewModal = () => {
        setShowViewModal(false);
    };
    useEffect(() => {
        AttendanceInfo()
    }, [])
    const admin_atenList = (data) => {
        let request = {
            attendance_id: data.attendance_id
        }
        API.post("admin_atenView/condition", request)
            .then((response) => {
                setViewRecord(response.data?.data[0]);
                setTimeout(() => {
                    setLoadingPopup(false);
                }, 1000)
            })
    }
    const AttendanceInfo = () => {

        API.post("admin_atenList/condition").then((response) => {
            setAttendanceList(response.data?.data)
            setTotalRecords(response.data?.data.length);
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    // ------------Search and filter----------------


    const Search = (data) => {

        let request = {
            data: data,
            status: ""
        }

        API.post("attendancesearch/condition", request).then(response => {
            setCurrentPage(1)
            setAttendanceList(response.data?.data)
            setTotalRecords(response.data?.data?.length);
        });
    }

    const Onchange = (data) => {
        Search(data);
    }

    return (
        <body>
            <Topbar />
            <Sidebar />
            <div class="main">
                <div class="d-flex justify-content-between">
                    <h2>
                        Attendance
                    </h2>
                    <div className="p15 m-1 justify-content-between d-flex">
                        <div className="dropdown" id="dropdown">
                            <div className="cenitems d-flex">
                                <form className="text-white border-0 mainform">
                                    <div className="d-flex">
                                        {/* <select >
                                            <option value="All">All</option>
                                            <option value="Dept1">Dept1</option>
                                            <option value="Dept2">Dept2</option>
                                            <option value="Dept3">Dept3</option>
                                        </select>
                                        &ensp; */}
                                        <input type="search" placeholder="Search.." id="myInput" onChange={(e) => Onchange(e.target.value)} />
                                    </div>
                                </form>
                            </div>
                        </div>
                        &ensp;
                    </div>
                </div>
                {loading ? <Loading /> :
                    <>
                        <div class="d-flex justify-content-between flex-wrap">
                            {attendanceList?.length > 0 ? attendanceList.sort((a, b) => b.attendanceList - a.attendanceList).slice(currentPage === 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage === 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                .map((attendanceList, index) =>
                                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">

                                        <div class="text-center">
                                            <img src={image} class="wh" />
                                            <h5>{attendanceList.employeename}</h5>
                                            <h6>{attendanceList.department}</h6>
                                            <div class="d-flex justify-content-around">
                                                <div>
                                                    <h6 class="bg-secondary-subtle rounded-5">80%</h6>
                                                    <h6>Month</h6>
                                                </div>
                                                <div>
                                                    <h6 class="card2 bg-secondary-subtle rounded-5">80%</h6>
                                                    <h6>Year</h6>
                                                </div>
                                            </div>
                                            <button type="button" onClick={() => handleShowViewModal(attendanceList)} class="nonav rounded-3 border-1" >
                                                View
                                            </button>
                                        </div>
                                    </div>
                                ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}

                        </div>
                        <br />
                        {loading ? <Loading /> :
                            <table class="wh100 bg-white shadow">
                                <thead>
                                    <tr class="ctext bb">
                                        <th>
                                            ID
                                        </th>
                                        <th>
                                            Name
                                        </th>
                                        <th>
                                            Department
                                        </th>
                                        <th>
                                            Date
                                        </th>
                                        <th>
                                            Login Time
                                        </th>
                                        <th>
                                            Logout Time
                                        </th>
                                        <th>
                                            Action
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {attendanceList?.length > 0 ? attendanceList.sort((a, b) => b.attendance_id - a.attendance_id).slice(currentPage === 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage === 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                        .map((attendanceList, index) =>
                                            <tr className=" bb" key={index}>
                                                <td>{attendanceList.attendance_id}</td>
                                                <td >{attendanceList.employeename}</td>
                                                <td>{attendanceList.department}</td>
                                                <td>{attendanceList.createdDate}</td>
                                                <td>{attendanceList.in_time}</td>
                                                <td>{attendanceList.out_time}</td>
                                                <td>

                                                    <button type="button" onClick={() => handleShowViewModal(attendanceList)} className="bg-white rounded-5 border-0 text-success">
                                                        <img src={eye} alt="" className="p20" />
                                                    </button>
                                                </td>
                                            </tr>

                                        ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}
                                </tbody>
                            </table>}
                    </>}
                <ul className="pagination">
                    <Pagination 
                        totalRecords={totalRecords}
                        pageLimit={pageLimit}
                        pageRangeDisplayed={1}
                        onChangePage={setCurrentPage}
                    />
                </ul>
            </div>

            <Modal size="wrapper modal-dialog-centered modal-lg" show={showViewModal} onHide={handleCloseViewModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Attendance Details</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>
                        <form>
                            <div class="row">
                            <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Attendance Id</label>
                                    <input type="text" className="form-control" value={viewRecord.attendance_id} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Name</label>
                                    <input type="text" className="form-control" value={viewRecord.employeename} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Department</label>
                                    <input type="text" className="form-control" value={viewRecord.department} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Date</label>
                                    <input type="text" className="form-control" value={viewRecord.createdDate} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">In-time</label>
                                    <input type="text" className="form-control" value={viewRecord.in_time} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Out-time</label>
                                    <input type="text" className="form-control" value={viewRecord.out_time} disabled />
                                </div>

                            </div>
                        </form>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseViewModal} className="close-btn">Close</button>
                    </div>
                </Modal.Footer>
            </Modal>

        </body>
    )
}


export default Attendance;