import React, { useState } from 'react';
import ls from 'local-storage';
import './css/bootstrap.min.css';
import API from '../src/baseServices/services.js';
import { useNavigate } from "react-router-dom";

function Login() {
    const navigate = useNavigate();
    const [name, setName] = useState("")
    const [pass, setPass] = useState("")
    const [err, setErr] = useState("")
    const [errPas, setErrPas] = useState("")
    const [error, setError] = useState("")

    const login = (e) => {
        e.preventDefault()
        setErr("");
        setErrPas("");
        setError("")

        if (!name) {
            setErr("Username is required.")
            return;
        }
        else if (name && !new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i).test(name)) {
            setErr( 'Must match the Username format' );
            return;
        }
        else if (!pass) {
            setErrPas("Password is required.")
            return;
        }
        let request={
            email: name,
            password: pass
        }
        API.post("adminlogin/login", request).then((response)=>{
            if (response.data.success == true){
                navigate('/dashboard');
                ls.set('userDetails', response.data.data[0]);
            }
            else{
                setError(response.data.error.mailError)
            }
        })
    }



    return (
        <header>

            <body class="bodyy bg-secondary-muted h-100">
                <div class="bodyy wrapper d-flex justify-content-center align-items-center p-5" >
                    <div class="start d-block bg-white shadow-lg pt-3 px-5 pb-3">
                        <i>
                            <h1 class="headingtype logoutb"><b>SBV Technologies <br /> Admin Portal</b></h1>
                        </i>
                        <hr></hr>
                        <h4 class="headingtype"><b>Login</b></h4>

                        <label>
                            <h6><b>Username</b></h6>
                        </label>

                        <input  class="form-control" placeholder="Enter your Username" name="name" type="text" size="30"
                            value={name} onChange={(e) => setName(e.target.value)}/>
                        <p class="text-danger">{err}</p>
                        <br />
                        <label>
                            <h6><b>Password</b></h6>
                        </label>
                        
                            <input  class="form-control" placeholder="Enter your password" name="password" type="password"
                                size="30" value={pass} onChange={(e) => setPass(e.target.value)} />
                            <p class="text-danger">{errPas}</p>
                            <p class="text-danger">{error}</p>
                        
                        <br />
                        <center><button class="loginbutton w-100 h-50 py-2 my-2 text-white border-0 " onClick={login}><a href="./dashboard.js" class="logouta">Submit</a></button></center>
                    </div>
                </div>
            </body>
        </header>
    );
}

export default Login;