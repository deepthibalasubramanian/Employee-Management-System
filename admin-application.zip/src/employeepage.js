import React, { useState, useEffect } from 'react';
import './overall.css';
// import image from "./profile.png";
import eye from "./eye-solid.svg";
import edit from "./pen-to-square-solid.svg";
import './css/bootstrap.min.css';
import Sidebar from './sidebar';
import Topbar from './topbar';
import AddEmployee from './addemployee';
import API from '../src/baseServices/services'
import Pagination from 'reactjs-hooks-pagination';
import adduser from '../src/adduser.jpg'
import Modal from 'react-bootstrap/Modal';
import Add from './plus.png';
import Loading from './loading';
import ls from "local-storage";
// import FileBase64 from 'react-file-base64';

const pageLimit = 10;
function Employeepage() {
    const [employeelist, setEmployeelist] = useState("");
    // const [employeInfo, setEmployeInfo] = useState("");
    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    // const [image,] = useState("");
    const [doc, setDoc] = useState("");
    const [loadingPopup, setLoadingPopup] = useState(true);
    const [type, setType] = useState("");
    const [showViewModal, setShowViewModal] = useState(false);
    const [viewRecord, setViewRecord] = useState(null);
    const [showEditModal, setShowEditModal] = useState(false);
    useEffect(() => {
        employeeList()
    }, [])
    const handleCloseViewModal = () => {
        setShowViewModal(false);
    };
    const handleShowViewModal = (data) => {
        employeeslist(data);
        setLoadingPopup(true);
        setShowViewModal(true);
    };
    const handleCloseEditModal = () => {
        setShowEditModal(false);
    };
    const handleShowEditModal = (record) => {
        setShowEditModal(true);
        employeeslist(record);
        setLoadingPopup(true);
    };

    const [empId, setEmpId] = useState('');
    const [fNameEdit, setFNameEdit] = useState('');
    const [lNameEdit, setLNameEdit] = useState('');
    const [emailEdit, setEmailEdit] = useState('');
    const [passwordEdit, setPsswordEdit] = useState('');
    const [phoneEdit, setPhoneEdit] = useState('');
    const [departmentEdit, setDepartmentEdit] = useState('');
    const [active, setActive] = useState('no');
    const [fNameEditError, setFNameEditError] = useState('');
    const [lNameEditError, setLNameEditError] = useState('');
    const [emailEditError, setEmailEditError] = useState('');
    const [passwordEditError, setPsswordEditError] = useState('');
    const [phoneEditError, setPhoneEditError] = useState('');
    const [departmentEditError, setDepartmentEditError] = useState('');

    const employeeslist = (data) => {

        let request = {
            employees_id: data.employees_id
        }
        API.post("employeeview/condition", request)
            .then((response) => {
                // setTotalRecords(response.data?.data.length);
                const empData = response.data?.data[0];
                setViewRecord(response.data?.data[0]);
                setEmpId(empData.employees_id);
                setFNameEdit(empData.first_name);
                setLNameEdit(empData.last_name);
                setEmailEdit(empData.email);
                setPsswordEdit(empData.password);
                setPhoneEdit(empData.phone_number);
                setActive(response.data?.data[0].active === 1 ? "yes" : "no")
                setDepartmentEdit(empData.department);
                setTimeout(() => {
                    setLoadingPopup(false);
                }, 1000)
            });
    };

    const empEdit = () => {
        setFNameEditError("");
        setLNameEditError("");
        setEmailEditError("");
        setPsswordEditError("");
        setPhoneEditError("");

        if (!fNameEdit) {
            setFNameEditError("First Name is required.")
            return;
        }
        else if (!lNameEdit) {
            setLNameEditError("Last Name is required.")
            return;
        }
        else if (!emailEdit) {
            setEmailEditError("Email is required.")
            return;
        }
        else if (emailEdit && !new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i).test(emailEdit)) {
            setEmailEditError('Must match the Email format');
            return;
        }
        else if (!passwordEdit) {
            setPsswordEditError("Password is required.")
            return;
        }
        else if (!phoneEdit) {
            setPhoneEditError("Phone Number is required.")
            return;
        }
        else if (phoneEdit.length < 10) {
            setPhoneEditError("PhoneNumber must have 10 digits");
            return;
        }
        else if (phoneEdit.length > 10) {
            setPhoneEditError("PhoneNumber accept only 10 digits");
            return;
        }
        else if (!departmentEdit) {
            setDepartmentEditError("Department is required.")
            return;
        }

        let request = {
            employees_id: empId,
            first_name: fNameEdit,
            last_name: lNameEdit,
            email: emailEdit,
            password: passwordEdit,
            phone_number: phoneEdit,
            department: departmentEdit,
            active: active === "yes" ? 1 : 4

        }

        API.post('employeeedit/update', request).then((response) => {
            if (response.data?.success === true) {
                employeeList();
                handleCloseEditModal();
            }
        })

    }

    const employeeList = () => {
        API.post("employeeslist/condition").then((response) => {
            setEmployeelist(response.data?.data)
            setTotalRecords(response.data?.data.length);
            setTimeout(() => {
                setLoading(false);
            }, 1000)
        })
    }
    // ================================Add admin=====================================

    const [show, setShow] = useState(false);
    const handleClose = () => {
        setShow(false);
        setFNameError("");
        setLNameError("");
        setEmailError("");
        setPsswordError("");
        setPhoneError("");
        setDepartmentError("");
    }
    const handleShow = () => setShow(true);
    const [fName, setFName] = useState('');
    const [lName, setLName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPssword] = useState('');
    const [phone, setPhone] = useState('');
    const [department, setDepartment] = useState('');
    const [fNameError, setFNameError] = useState('');
    const [lNameError, setLNameError] = useState('');
    const [emailError, setEmailError] = useState('');
    const [passwordError, setPsswordError] = useState('');
    const [phoneError, setPhoneError] = useState('');
    const [error, setError] = useState("");
    const [departmentError, setDepartmentError] = useState('');

    const handleSubmit = () => {
        setFNameError("");
        setLNameError("");
        setEmailError("");
        setPsswordError("");
        setPhoneError("");
        setError("");

        if (!fName) {
            setFNameError("First Name is required.")
            return;
        }
        else if (!lName) {
            setLNameError("Last Name is required.")
            return;
        }
        else if (!email) {
            setEmailError("Email is required.")
            return;
        }
        else if (email && !new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i).test(email)) {
            setEmailError('Must match the Email format');
            return;
        }
        else if (!password) {
            setPsswordError("Password is required.")
            return;
        }
        else if (!phone) {
            setPhoneError("Phone Number is required.")
            return;
        }
        else if (phone.length < 10) {
            setPhoneError("PhoneNumber must have 10 digits");
            return;
        }
        else if (phone.length > 10) {
            setPhoneError("PhoneNumber accept only 10 digits");
            return;
        }
        else if (!department) {
            setDepartmentError("Department is required.")
            return;
        }

        let request = {
            first_name: fName,
            last_name: lName,
            email: email,
            password: password,
            phone_number: phone,
            department: department,
            createdBy: 1,
            updatedBy: 1
        }

        API.post('addemployee/add', request).then((response) => {
            if (response.data.success == true) {
                employeeList();
                handleClose();
            } else {
                setError(response.data.error.err)
            }
        })

    };
    const getFiles = (file) => {
        console.log("================>", file.type)
        setType("")
        if (file.type.includes("jpg") || file.type.includes("jpeg") || file.type.includes("png")) {
            setDoc(file);
        } else {
            setType("0");
        }
    }

    // ------------Search and filter----------------

    const [search, setSearch] = useState("");
    const [dropdown, setDropdown] = useState("");


    const Search = (drop, search) => {

        let request = {
            data: search,
            status: drop
        }

        API.post("employeesearch/condition", request).then(response => {
            setCurrentPage(1)
            setEmployeelist(response.data?.data)
            setTotalRecords(response.data?.data.length);
        });
    }

    const Onchange = (drop, search) => {
        Search(drop, search);
    }

    return (
        <body>
            <Topbar />
            <Sidebar />
            <div className="main">
                <div className="d-flex justify-content-between">
                    <h2>Employees</h2>
                    <div className="p15 m-1 justify-content-between d-flex">
                        <div className="dropdown" id="dropdown">
                            <div className="cenitems d-flex">
                                <form className="text-white border-0 mainform">
                                    <div className="d-flex">
                                        <select onChange={(e) => { setDropdown(e.target.value); Onchange(e.target.value, search) }}>
                                            <option style={{ display: "none" }}>Select Status</option>
                                            <option value="">All</option>
                                            <option value="Active">Active</option>
                                            <option value="Inactive">Inactive</option>
                                        </select>
                                        &ensp;
                                        <input type="search" placeholder="Search.." id="myInput" onChange={(e) => { setSearch(e.target.value); Onchange(dropdown, e.target.value) }} />
                                    </div>
                                </form>
                            </div>
                        </div>
                        &ensp;
                        <button type="button" onClick={handleShow} className="rounded-5 border-2">
                            <img src={Add} className="p20" /> Add Employee
                        </button>
                    </div>
                </div>
                <br />
                {loading ? <Loading /> :
                    <table className="bg-white shadow wh100" >
                        <thead>
                            <tr className="ctext bb" >
                                <th>ID</th>
                                <th>Employee Name</th>
                                {/* <th>Image</th> */}
                                <th>Email</th>
                                <th>Password</th>
                                <th>Phone Number</th>
                                <th>Department</th>
                                <th>Created on</th>
                                <th>Created by</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {employeelist.length > 0 ? employeelist.sort((a, b) => b.employees_id - a.employees_id).slice(currentPage == 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage == 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                .map((employeelist, index) =>
                                    <tr className=" bb" key={index}>
                                        <td>{employeelist.employees_id}</td>
                                        <td >{employeelist.employeeName}</td>
                                        {/* <td> <img className='admin-image' src={employeInfo.admin_image || adduser} /></td> */}
                                        <td>{employeelist.email}</td>
                                        <td>{employeelist.password}</td>
                                        <td>{employeelist.phone_number}</td>
                                        <td>{employeelist.department}</td>
                                        <td>{employeelist.createdDate}</td>
                                        <td>{employeelist.CreatedBy}</td>
                                        {employeelist.active === 1 ?
                                            <td><span className="active-color">Active</span></td> :
                                            <td><span className="inactive-color">Inactive</span></td>
                                        }
                                        <td>
                                            <button type="button" onClick={() => handleShowViewModal(employeelist)} className="bg-white rounded-5 border-0 text-success">
                                                <img src={eye} alt="" className="p20" />
                                            </button>
                                            <button type="button" onClick={() => handleShowEditModal(employeelist)} className="bg-white rounded-5 border-0 text-success">
                                                <img src={edit} alt="" className="p20" />
                                            </button>
                                        </td>
                                    </tr>

                                ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}
                        </tbody>
                    </table>}
                <ul className="pagination">
                    <Pagination className=""
                        totalRecords={totalRecords}
                        pageLimit={pageLimit}
                        pageRangeDisplayed={1}
                        onChangePage={setCurrentPage}
                    />
                </ul>
            </div>
            {/* ===========================Add Admin============================ */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Add Employee</h3>
                </Modal.Header>

                <Modal.Body>
                    <div className="col-lg-2 buttons-aln">
                        <div className="col-lg-12 ">

                            {/* <div className="user-upload-btn-wrapper">
                                {(image === "" || image == null || image == undefined) && doc === "" ? <img alt="" src={adduser} /> :
                                    doc === "" ? <img alt="" src={image} /> :
                                        <img alt="" src={doc.base64} />}
                                <span className="proCamera"></span>
                                <FileBase64 onDone={getFiles} className="hidden-image" type="hidden" />

                                {type === "0" ? <p className="text-danger">Upload only Image Format </p> : ""}
                            </div> */}
                        </div>
                    </div>
                    <br />
                    <form>
                        <div className="row">
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">First Name</label>
                                <input type="text" className="form-control" onChange={(e) => setFName(e.target.value)} />
                                <p className="text-danger">{fNameError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Last Name</label>
                                <input type="text" className="form-control" onChange={(e) => setLName(e.target.value)} />
                                <p className="text-danger">{lNameError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Email</label>
                                <input type="text" className="form-control" onChange={(e) => setEmail(e.target.value)} />
                                <p className="text-danger">{emailError}</p>
                                <p className="text-danger">{error}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Password</label>
                                <input type="text" className="form-control" onChange={(e) => setPssword(e.target.value)} />
                                <p className="text-danger">{passwordError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Phone Number</label>
                                <input type="text" className="form-control" onChange={(e) => setPhone(e.target.value)} />
                                <p className="text-danger">{phoneError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Department</label>
                                <input type="text" className="form-control" onChange={(e) => setDepartment(e.target.value)} />
                                <p className="text-danger">{departmentError}</p>
                            </div>
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer >
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleClose} className="close-btn">Close</button>&ensp;
                        <button type="submit" onClick={handleSubmit} className="submit-btn ">Submit</button>
                    </div>
                </Modal.Footer>
            </Modal>

            {/* ===========================View Employee Details============================ */}

            <Modal size="wrapper modal-dialog-centered modal-lg" show={showViewModal} onHide={handleCloseViewModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Employee Details</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>
                        <div class="row">
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Employee Id</label>
                                <input type="text" className="form-control" value={viewRecord.employees_id} disabled />
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">First Name</label>
                                <input type="text" className="form-control" value={viewRecord.first_name} disabled />
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Last Name</label>
                                <input type="text" className="form-control" value={viewRecord.last_name} disabled />

                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Email</label>
                                <input type="text" className="form-control" value={viewRecord.email} disabled />

                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Password</label>
                                <input type="text" className="form-control" value={viewRecord.password} disabled />

                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Phone Number</label>
                                <input type="text" className="form-control" value={viewRecord.phone_number} disabled />

                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Department</label>
                                <input type="text" className="form-control" value={viewRecord.department} disabled />

                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="email" className="col-form-label">Status</label>
                                <div className="form-check form-switch">
                                    <input className="form-check-input me-2" type="checkbox" id="flexSwitchCheckChecked" checked={viewRecord.active === 1 ? true : false} disabled />
                                </div>
                            </div>
                        </div>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseViewModal} className="close-btn">Close</button>
                    </div>
                </Modal.Footer>
            </Modal>

            {/* =====================================Edit Employee Details================================== */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={showEditModal} onHide={handleCloseEditModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Employee Details</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>
                        <form>

                            <div class="row">
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Employee Id</label>
                                    <input type="text" className="form-control" value={empId} disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>First Name</h5></label>
                                    <input className="form-control" value={fNameEdit} onChange={(e) => setFNameEdit(e.target.value)} />
                                    <p className="text-danger">{fNameEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Last Name</h5></label>
                                    <input className="form-control" value={lNameEdit} onChange={(e) => setLNameEdit(e.target.value)} />
                                    <p className="text-danger">{lNameEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Email</h5></label>
                                    <input className="form-control" value={emailEdit} onChange={(e) => setEmailEdit(e.target.value)} />
                                    <p className="text-danger">{emailEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Password</h5></label>
                                    <input className="form-control" value={passwordEdit} onChange={(e) => setPsswordEdit(e.target.value)} />
                                    <p className="text-danger">{passwordEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label"><h5>Phone Number</h5></label>
                                    <input className="form-control" value={phoneEdit} onChange={(e) => setPhoneEdit(e.target.value)} />
                                    <p className="text-danger">{phoneEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Department</label>
                                    <input type="text" className="form-control" value={departmentEdit} onChange={(e) => setDepartmentEdit(e.target.value)} />
                                    <p className="text-danger">{departmentEditError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="email" className="col-form-label">Status</label>
                                    <div className="form-check form-switch">
                                        <input className="form-check-input me-2" type="checkbox" id="flexSwitchCheckChecked" value={active === "no" ? "yes" : "no"} checked={active == "yes" ? true : false} onChange={(e) => setActive(e.target.value)} />
                                    </div>
                                </div>
                            </div>

                        </form>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseEditModal} className="close-btn">Close</button>&ensp;
                        <button type="submit" onClick={empEdit} className="submit-btn ">Submit</button>
                    </div>
                </Modal.Footer>
            </Modal>


        </body>
    )
}

export default Employeepage;
