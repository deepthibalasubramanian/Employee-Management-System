import React from 'react';
import ReactDOM from 'react-dom/client';
import '../assets/employeedstyle.css';
import Login from "./employeelogin";
import image from "../assets/profile.png";
import attendance from "../assets/attendance.png";
import month from "../assets/month.png";
import naukri from "../assets/naukri.png";
import week from "../assets/week.png";
import day from "../assets/day.png";
import '../css/bootstrap.min.css';
import Emppage from './emppage';
import { FaSignOutAlt } from "react-icons/fa";
import { FaGlobe } from "react-icons/fa";
import { FaGithub } from "react-icons/fa";
import { FaLinkedin } from "react-icons/fa";
import { useState, useEffect } from 'react';
import TopBar from './topbar.js';
import SideBar from './sidebar.js';
import ls from 'local-storage';
import API from "./base_services/service";
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';
import Loading from './loading';

function Profile() {
    const data = ls.get('userDetails');
    const [empInfo, setEmpInfo] = useState("");
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        empList()
    }, [])
    const empList = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("employeeview/condition", request).then((response) => {
            setEmpInfo(response.data.data[0])
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    return (
        <body>
            <TopBar data={data}/>
            <SideBar />
            <div class="main">
                <h2>Employee Profile</h2>
                {loading ? <Loading /> :
                    <div class="row">
                        <div class="col-6 p-5 d-grid ">
                            <center>
                                <img src={image} height="200px" width="200px" class="rounded-4" />
                                <br />
                                <h3 class="mt-3">Sample Name</h3>
                                <h4>Software Engineer</h4>

                                <table class="table table-borderless rounded shadow px-2 mt-3 border-0 tname">
                                    <tr class=" px-1 border-0">

                                        <td class="px-2 py-2 border-0 text-black"><span><FaGlobe /></span>Website</td>
                                        <td class="text-end px-2 border-0"><a href="#" class="text-primary">sample.com</a></td>

                                    </tr>

                                    <tr class=" px-1">
                                        <td class="px-2 py-2 border-0 text-black"><span><FaLinkedin /></span>Linkedin</td>
                                        <td class="text-end px-2 border-0"><a href="#" class="text-primary">sample.com</a></td>

                                    </tr>
                                    <tr class=" px-1">
                                        <td class="px-2 py-2 border-0 text-black"><img src={naukri} height="30px" width="30px" />Naukri.com</td>
                                        <td class="text-end px-2 border-0"><a href="#" class="text-primary">sample.com</a></td>

                                    </tr>
                                </table>
                            </center>

                        </div>
                        <div class="col-6" >
                            <div class="card card1 w-100 mt-3 p-2 mx-2 mb-2 shadow  h-auto rounded-2"  >
                                <h6>Employee ID</h6>
                                <span class="text-secondary val" >{empInfo.employees_id}</span>
                            </div>
                            <div class="card card1 w-100 mt-3 p-2 mx-2 mb-2 shadow  h-auto rounded-2"  >
                                <h6>Full name</h6>
                                <span class="text-secondary val" >{empInfo.employeeName}</span>
                            </div>
                            <div class="card card1 w-100 mt-3 p-2 mx-2 mb-2 shadow rounded-2 h-auto">
                                <h6>Mobile</h6>
                                <span class="text-secondary val" >{empInfo.phone_number}</span>
                            </div>
                            <div class="card card1 w-100 mt-3 p-2 mx-2 mb-2 shadow rounded-2 h-auto">
                                <h6>Email</h6>
                                <span class="text-secondary val" >{empInfo.email}</span>
                            </div>
                            <div class="card card1 w-100 mt-3 p-2 mx-2 mb-2 shadow rounded-2 h-auto">
                                <h6>Department</h6>
                                <span class="text-secondary val" > {empInfo.department}</span>
                            </div>
                            <div class="card card1 w-100 mt-3 p-2 mx-2 mb-2 shadow rounded-2 h-auto">
                                <h6>Date of Joining</h6>
                                <span class="text-secondary val" > {empInfo.createdDate}</span>
                            </div>


                        </div>
                    </div>}
            </div> 
        </body>
    )
}

export default Profile;