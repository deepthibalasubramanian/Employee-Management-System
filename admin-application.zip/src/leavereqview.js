import { useState } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';

function LeaveRequestView() {
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    return (
        <>
            <button type="button" onClick={handleShow} className="logouta bg-secondary border-0">
                View
            </button>

            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class='col-12 modal-title text-center'>
                        Reasons
                    </h3>
                </Modal.Header>
                <Modal.Body>Woohoo, you are reading this text in a modal!</Modal.Body>
                <Modal.Footer >
                    <button type="button" onClick={handleClose} className="logoutc text-white rounded-5 border-0 p-2">Close </button>
                </Modal.Footer>
            </Modal>
        </>
    );
}

export default LeaveRequestView;