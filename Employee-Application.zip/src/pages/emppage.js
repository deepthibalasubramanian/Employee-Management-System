import '../assets/employeedstyle.css';
import '../css/bootstrap.min.css';
import AddRequest from './addrequest.js';
import EditRequest from './editrequest.js';
import { useState, useEffect } from 'react';
import ls from 'local-storage';
import API from "./base_services/service";
import TopBar from './topbar.js';
import SideBar from './sidebar.js';
import Pagination from 'reactjs-hooks-pagination';
import Modal from 'react-bootstrap/Modal';
import add from "../assets/Plus green.png";
import edit from "../assets/pen-to-square-solid.svg";
import eye from "../assets/eye-solid.svg";
import Loading from './loading';

const pageLimit = 10;
function Emppage() {
    const data = ls.get('userDetails');

    const [leaveInfo, setLeaveInfo] = useState("");
    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    const [loadingPopup, setLoadingPopup] = useState(true);
    const [editRecord, setEditRecord] = useState(null);
    const [view, setView] = useState("");
    useEffect(() => {
        leaveList()
    }, [])
    const leaveList = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("employeeleavelist/condition", request).then((response) => {
            setLeaveInfo(response.data.data)
            setTotalRecords(response.data.data.length);
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    // ================================Add admin=====================================

    const [show, setShow] = useState(false);
    const [show1, setShow1] = useState(false);
    const handleClose = () => {
        setShow(false);
        setShow1(false);
        setFromDateError("");
        setToDateError("");
        setTypeError("");
        setReasonError("");
    }
    const handleShow = () => setShow(true);
    const handleShow1 = () => setShow1(true);
    const [fromDate, setFromDate] = useState('');
    const [toDate, setToDate] = useState('');
    const [type, setType] = useState('');
    const [reason, setReason] = useState('');
    const [showEditModal, setShowEditModal] = useState(false);
    const [showViewModal, setShowViewModal] = useState(false);

    const [fromDateError, setFromDateError] = useState('');
    const [toDateError, setToDateError] = useState('');
    const [typeError, setTypeError] = useState('');
    const [reasonError, setReasonError] = useState('');



    const handleSubmit = () => {
        setFromDateError("");
        setToDateError("");
        setTypeError("");
        setReasonError("");

        if (!fromDate) {
            setFromDateError("From Date is required.")
            return;
        }
        else if (!toDate) {
            setToDateError("To Date is required.")
            return;
        }
        else if (!type) {
            setTypeError("Type is required.")
            return;
        }
        else if (!reason) {
            setReasonError("Password is required.")
            return;
        }

        let request = {
            employees_id: data.employees_id,
            type: type,
            reasons: reason,
            from_date: fromDate,
            to_date: toDate,
            createdBy: data.employees_id,
            updatedBy: data.employees_id
        }

        API.post('addemployeesleave/add', request).then((response) => {
            if (response.data.success == true) {
                leaveList();
                handleClose();
            }
        })

    };

    // =====================================View=======================================


    const handleShowViewModal = (data) => {
        setShowViewModal(true);
        leaveView(data);
        setLoadingPopup(true);
    };
    const handleCloseViewModal = () => {
        setShowViewModal(false);
    };

    const leaveView = (data) => {

        let request = {
            leave_id: data.leave_id
        }

        API.post("employeeleaveview/condition", request).then((response) => {
            setView(response.data?.data[0])
            setId(response.data?.data[0].leave_id)
            setEditFromDate(response.data?.data[0].from_date)
            setEditToDate(response.data?.data[0].to_date)
            setEditReason(response.data?.data[0].reasons)
            setEditType(response.data?.data[0].type)
            setTimeout(() => {
                setLoadingPopup(false);
            }, 1000)

        })
    }

    // ==============================Edit=================================

    const handleShowEditModal = (data) => {
        setShowEditModal(true);
        leaveView(data);
        setLoadingPopup(true);
    };

    const handleCloseEditModal = () => {
        setShowEditModal(false);
        setFromDateError('');
        setToDateError('');
        setTypeError('');
        setReasonError('');
        setEditFromDate("")
    };

    const [id, setId] = useState('');
    const [editFromDate, setEditFromDate] = useState('');
    const [editToDate, setEditToDate] = useState('');
    const [editType, setEditType] = useState('');
    const [editReason, setEditReason] = useState('');
    const [editFromDateError, setEditFromDateError] = useState('');
    const [editToDateError, setEditToDateError] = useState('');
    const [editTypeError, setEditTypeError] = useState('');
    const [editReasonError, setEditReasonError] = useState('');

    const handleEditSubmit = () => {

        setFromDateError('');
        setToDateError('');
        setTypeError('');
        setReasonError('');

        if (!editFromDate) {
            setEditFromDateError('From Date is required.');
            return;
        } else if (!editToDate) {
            setEditToDateError('To Date is required.');
            return;
        } else if (!editType) {
            setEditTypeError('Type is required.');
            return;
        } else if (!editReason) {
            setEditReasonError('Reason is required.');
            return;
        }

        let request = {
            leave_id: id,
            type: editType,
            reasons: editReason,
            from_date: editFromDate,
            to_date: editToDate,
        };

        API.post("leaveEdit/update", request)
            .then((response) => {
                if (response.data.success) {
                    leaveList();
                    handleCloseEditModal();
                }
            });

    };

    return (
        <body>
            <TopBar data={data}/>
            <SideBar />
            <div className="main">
                <div className="d-flex justify-content-between">
                    <h2><b>Employee Leave Info</b></h2>
                    <div className="p15 m-1 justify-content-between d-flex">

                        <button type="button" onClick={handleShow} className="bg-white rounded-5 border-2 text-success" >

                            <img src={add} className="p20" /> Add Request

                        </button>
                    </div>
                </div>
                {loading ? < Loading /> :
                    <table className=" bg-white shadow wh100 text-black border-0 table3" id="mytable" >
                        <thead>
                            <tr class="bb text-black">

                                <th class="text-start text-black border-0 th3">
                                    From
                                </th>
                                <th class="text-start text-black border-0 th3">
                                    To
                                </th>
                                <th class="text-start text-black border-0 th3">
                                    Applied on
                                </th>

                                <th class="text-start text-black border-0 th3">Reason</th>

                                <th class="text-start text-black border-0 th3">
                                    Type
                                </th>


                                <th class="text-start text-black border-0 th3">Status</th>
                                <th class="text-start text-black border-0 th3">Action</th>


                            </tr>
                        </thead>
                        <tbody>
                            {leaveInfo.length > 0 ? leaveInfo.sort((a, b) => b.leave_id - a.leave_id).slice(currentPage == 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage == 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                .map((leaveInfo, index) =>
                                    <tr className=" bb text-black" key={index}>
                                        <td className="text-black border-0 td3">{leaveInfo.from_date}</td>
                                        <td className="text-black border-0 td3">{leaveInfo.to_date}</td>
                                        <td className="text-black border-0 td3">{leaveInfo.createdDate}</td>
                                        <td className="text-black border-0 td3 overflow">{leaveInfo.reasons}</td>
                                        <td className="text-black border-0 td3">{leaveInfo.type}</td>
                                        {leaveInfo.active === 1 ?
                                            <td><span className="active-color">Approve</span></td> :
                                            leaveInfo.active === 4 ?
                                                <td><span className="inactive-color">Reject</span></td> :
                                                <td><span className="pending-color">Pending</span></td>
                                        }
                                        <td>
                                            <button type="button" onClick={() => handleShowViewModal(leaveInfo)} className="bg-white rounded-5 border-0 text-success" >
                                                <img src={eye} className="p20" />
                                            </button>
                                            <button type="button" onClick={() => handleShowEditModal(leaveInfo)} className="bg-white rounded-5 border-0 text-success" >
                                                <img src={edit} className="p20" />
                                            </button>

                                        </td>
                                    </tr>

                                ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}
                        </tbody>
                    </table>}
                <ul className="pagination">
                    <Pagination className=""
                        totalRecords={totalRecords}
                        pageLimit={pageLimit}
                        pageRangeDisplayed={1}
                        onChangePage={setCurrentPage}
                    />
                </ul>
            </div>
            {/* ===========================Add Admin============================ */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Add Request</h3>
                </Modal.Header>

                <Modal.Body>

                    <form>
                        <div className="row">
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">From Date</label>
                                <input type="date" className="form-control" onChange={(e) => setFromDate(e.target.value)} />
                                <p className="text-danger">{fromDateError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">To Date</label>
                                <input type="date" className="form-control" onChange={(e) => setToDate(e.target.value)} />
                                <p className="text-danger">{toDateError}</p>
                            </div>
                            <div className="col-lg-4 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Type</label>
                                <select className="form-control" onChange={(e) => setType(e.target.value)}>
                                <option style={{ display: "none" }}>Select Type</option>
                                    <option value="Sick">Sick</option>
                                    <option value="Personal">Personal</option>
                                </select>
                                <p className="text-danger">{typeError}</p>
                            </div>
                            <div className="col-lg-12 mb-3 add-language">
                                <label htmlFor="user-name" className="col-form-label">Reason</label>
                                <textarea type="text" className="form-control" rows="2" onChange={(e) => setReason(e.target.value)} />
                                <p className="text-danger">{reasonError}</p>
                            </div>
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer >
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleClose} className="close-btn">Close</button>&ensp;
                        <button type="submit" onClick={handleSubmit} className="submit-btn ">Submit</button>
                    </div>
                </Modal.Footer>
            </Modal>
            {/* ===========================Edit============================ */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={showEditModal} onHide={handleCloseEditModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">Edit Request</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>
                        <form>
                            <div className="row">
                            <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">LeaveId</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={id}
                                        disabled
                                    />
                                    <p className="text-danger">{editFromDateError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">From Date</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={editFromDate}
                                        onChange={(e) => setEditFromDate(e.target.value)}
                                    />
                                    <p className="text-danger">{editFromDateError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">To Date</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={editToDate}
                                        onChange={(e) => setEditToDate(e.target.value)}

                                    />
                                    <p className="text-danger">{editToDateError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Type</label>
                                    <select
                                        className="form-control"
                                        value={editType}
                                        onChange={(e) => setEditType(e.target.value)}
                                    >
                                        <option value="Sick">Sick</option>
                                        <option value="Personal">Personal</option>
                                    </select>
                                    <p className="text-danger">{editTypeError}</p>
                                </div>
                                <div className="col-lg-8 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Reason</label>
                                    <textarea
                                        type="text"
                                        className="form-control"
                                        rows="2"
                                        value={editReason}
                                        onChange={(e) => setEditReason(e.target.value)}
                                    />
                                    <p className="text-danger">{editReasonError}</p>
                                </div>
                            </div>
                        </form>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseEditModal} className="close-btn">Close</button>&ensp;
                        <button type="submit" onClick={handleEditSubmit} className="submit-btn ">Submit</button>

                    </div>
                </Modal.Footer>
            </Modal>
            {/* ===========================View============================ */}
            <Modal size="wrapper modal-dialog-centered modal-lg" show={showViewModal} onHide={handleCloseViewModal}>
                <Modal.Header closeButton>
                    <h3 class="col-12 modal-title text-center">View Request</h3>
                </Modal.Header>
                {loadingPopup ? <Loading /> :
                    <Modal.Body>
                        <form>
                            <div className="row">
                            <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">LeaveId</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={view.leave_id}
                                        disabled
                                    />
                                    <p className="text-danger">{editFromDateError}</p>
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">From Date</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={view.from_date}
                                        disabled />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">To Date</label>
                                    <input
                                        type="date"
                                        className="form-control"
                                        value={view.to_date}
                                        disabled
                                    />
                                </div>
                                <div className="col-lg-4 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Type</label>
                                    <input
                                        type="text"
                                        className="form-control"
                                        value={view.type}
                                        disabled
                                    />
                                </div>
                                <div className="col-lg-12 mb-3 add-language">
                                    <label htmlFor="user-name" className="col-form-label">Reason</label>
                                    <textarea
                                        type="text"
                                        className="form-control"
                                        rows="2"
                                        value={view.reasons}
                                        disabled />
                                </div>
                            </div>
                        </form>
                    </Modal.Body>}
                <Modal.Footer>
                    <div className='buttons-aln'>
                        <button type="submit" onClick={handleCloseViewModal} className="close-btn">Close</button>&ensp;

                    </div>
                </Modal.Footer>
            </Modal>
        </body>
    )
}
export default Emppage;