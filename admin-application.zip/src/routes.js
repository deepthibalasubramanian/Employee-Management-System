import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import React from "react";
import Login from "./loginpage";
import Dashboard from "./dashboard";
import Adminpage from "./adminpage";
import '../src/overall.css';
import '../src/css/bootstrap.min.css';
import Employeepage from "./employeepage";
import Attendance from "./attendance";
import Leave from "./leaverequest";
// import '../src/vendor/fontawesome/css/all.css';

const AppRouter = () => {
    return (
        <div>
            <Router>
                <Routes>
                    <Route exact path="/" element={<Login />} />
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/adminpage" element={<Adminpage />} />
                    <Route path="/employeepage" element={<Employeepage />} />
                    <Route path="/attendance" element={<Attendance />} />
                    <Route path="/leaverequest" element={<Leave />} />
                </Routes>
            </Router>

        </div>
    );
}
export default AppRouter;

