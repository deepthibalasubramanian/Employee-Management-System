import React from 'react';
import { RotatingLines } from 'react-loader-spinner'


// const Loading = () => {
//     return (
//         <div style={{ height: '65vh', display: 'flex', 'align-items': 'center', 'justify-content': 'center', 'margin-left': '50%' }}>

//             <RotatingLines
//                 strokeColor="#102b8c "
//                 strokeWidth="1"
//                 animationDuration="0.99"
//                 width="60"
//                 visible={true}
//             />

//         </div>
//     );
// };

// export default Loading;
// import ReactLoading from 'react-loading';

const Loading = () => {
    return (
        <div style={{ height: '80vh', display: 'flex', 'align-items': 'center', 'justify-content': 'center' }}>

            {/* <ReactLoading type="spokes" color="#002768" height={'5%'} width={'5%'} /> */}
            <RotatingLines
                strokeColor="#102b8c "
                strokeWidth="1"
                animationDuration="0.99"
                width="80"
                visible={true}
            />

        </div>
    );
};

export default Loading;