import React from 'react';
import ReactDOM from 'react-dom/client';
import './overall.css';
import Login from "./loginpage";
import image from "./profile.png";
import attendance from "./attendance.png";
import './css/bootstrap.min.css';
import LogoutRequest from './logoutreq';   
import ls from "local-storage"; 
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';

function Topbar() {
    const data = ls.get('userDetails');
    return (
        <body>


            <div className="topbar shadow d-flex justify-content-between px-2 bg-white">
                <h2 className="bodycolor mt-auto mb-auto"><b><i>LOGO</i></b></h2>
                <div className="d-flex">
                    <h6 className="welcome">Welcome, {data.first_name} {data.last_name} <img src={image} alt="Profile" className="imgd" /></h6>
                    <LogoutRequest />
                </div>
            </div>
            </body>
)}
export default Topbar;