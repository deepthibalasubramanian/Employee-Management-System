import { useState, useEffect } from 'react';
import Button from 'react-bootstrap/Button';
import '../css/bootstrap.min.css';
import add from "../assets/Plus green.png";
import Col from 'react-bootstrap/Col';
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import Row from 'react-bootstrap/Row';
import FormGroup from 'react-bootstrap/FormGroup';
import Modal from 'react-bootstrap/Modal';
import edit from "../assets/pen-to-square-solid.svg";


function EditRequest() {
    const [show, setShow] = useState(false);
    const [pass, setPass] = useState('');
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [validated, setValidated] = useState(false);
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const handleSubmit = (event) => {
        const form = event.currentTarget;
        if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
        }

        setValidated(true);
    };

   

    return (
        <>
        <button type="button" onClick={handleShow} className="bg-white border-0 text-success" >
            <img src={edit} height="25px" width="25px" />   
            
       
    </button>

    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
            <h3 class="col-12 modal-title text-center">Edit Request</h3>
        </Modal.Header>
        <Modal.Body><Form noValidate validated={validated} onSubmit={handleSubmit}>
            <Row className="mb-3 justify-content-between">
                <Form.Group as={Col} md="6" controlId="validationCustom01">
                    <Form.Label>From Date</Form.Label>
                    <Form.Control
                        required
                        type="Date"
                        placeholder="From date"
                    />
                    <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                        Please enter a date
                    </Form.Control.Feedback>
                </Form.Group>
                
                <Form.Group as={Col} md="6" controlId="validationCustom02">
                    <Form.Label>To Date</Form.Label>
                    <Form.Control
                        required
                        type="Date"
                        placeholder="To date"
                    />
                    <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
                    <Form.Control.Feedback type="invalid">
                        Please enter a date
                    </Form.Control.Feedback>
                </Form.Group>
                </Row>
                <Row>
                    <Form.Group md="4" controlId="validationCustomUsername">
                        <Form.Label>Type</Form.Label>
                        <InputGroup hasValidation>
                            
                            <FormGroup>
                                <Form.Check type="radio" id="radio1" name="type" custom checked label="Sick" />
                                <Form.Check type="radio" id="radio1" name="type" custom label="Personal" />
                              </FormGroup>
                            
                            <Form.Control.Feedback type="invalid">
                                Please type a reason.
                            </Form.Control.Feedback>
                        </InputGroup>
                    </Form.Group>
                <br />
                <Form.Group md="4" controlId="validationCustomUsername">
                    <Form.Label>Reason</Form.Label>
                    <InputGroup hasValidation>
                        
                        <Form.Control
                            type="text"
                            placeholder="Enter your reason"
                            required
                            
                            onChange={(e) => setEmail(e.target.value)}
                            
                        />
                        
                        <Form.Control.Feedback type="invalid">
                            Please type a reason.
                        </Form.Control.Feedback>
                    </InputGroup>
                </Form.Group>
                </Row>
                <br />
            {/* <Form.Group md="4" controlId="validationCustomUsername">
                <Form.Label>Password</Form.Label>
                <InputGroup hasValidation>

                    <Form.Control
                        type="password"
                        placeholder="Password"
                        required
                        onChange={(e) => setPass(e.target.value)}
                    />
                    
                    <Form.Control.Feedback type="invalid">
                        Please enter a password.
                    </Form.Control.Feedback>
                </InputGroup>
            </Form.Group> */}

            <Row>
            
            </Row>
            <br />
            
        </Form></Modal.Body>
        <Modal.Footer >
            
            <button type="submit" onClick={handleSubmit} className="bg-success text-white rounded-5 border-0 mx-auto" >&ensp;Create Request&ensp;</button>
            
        </Modal.Footer>
    </Modal>
        </>
    );
}

export default EditRequest;