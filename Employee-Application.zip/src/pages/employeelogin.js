import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import '../assets/employeedstyle.css';
import '../css/bootstrap.min.css';
import { useNavigate } from "react-router-dom";
import { Icon } from 'react-icons-kit';
import { eyeOff } from 'react-icons-kit/feather/eyeOff';
import { eye } from 'react-icons-kit/feather/eye'
import API from "./base_services/service";
import ls from 'local-storage';

const Login = () => {
  const navigate = useNavigate();
  const [name, setName] = useState("")
  const [pass, setPass] = useState("")
  const [err, setErr] = useState("")
  const [error, setError] = useState("")
  const [errPas, setErrPas] = useState("")
  const [password, setPassword] = useState("");
  const [type, setType] = useState('password');
  const [icon, setIcon] = useState(eyeOff);
  const handleToggle = () => {
    if (type === 'password') {
      setIcon(eye);
      setType('text')
    } else {
      setIcon(eyeOff)
      setType('password')
    }
  }
  const login = (e) => {
    e.preventDefault()
    setErr("");
    setErrPas("");
    setError("");
    if (!name) {
      setErr("Username is required")
      return;
    }
    else if (name && !new RegExp(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i).test(name)) {
      setErr('Must match the Username format');
      return;
    }
    else if (!password) {
      setErrPas("password is required")
      return;
    }
    let request = {
      email: name,
      password: password
    }
    API.post('employeelogin/login', request).then((response) => {
      if (response.data.success == true) {
        ls.set('userDetails', response.data.data[0]);
        navigate('/employeedashboard')
      }
      else {
        setError(response.data.error.mailError)

      }
    })
  }

  return (
    <header>

      <body class="bodyy bg-secondary-muted h-100">
        <div class="bodyy wrapper d-flex justify-content-center align-items-center p-5" >
          <div class="start d-block bg-white shadow-lg pt-3 px-5 pb-3">
            <i>
              <h1 class="headingtype logoutb"><b>SBV Technologies <br /> Admin Portal</b></h1>
            </i>
            <hr></hr>
            <h4 class="headingtype text-center"><b>Login</b></h4>
            <form action="" class="needs-validation" novalidate>
              <label>
                <h6><b>Username</b></h6>
              </label>
              <div class="mb-0 d-flex border-1 form-control trial h-50">
                <input class="form-control border-0" placeholder="Enter your Username" name="name" type="text" size="30"
                  value={name} onChange={(e) => setName(e.target.value)} />
              </div>
              <p class="text-danger">{err}</p>
              <br />
              <label>
                <h6><b>Password</b></h6>
              </label>

              <div class="mb-0 d-flex border-1 form-control trial h-50">
                <input
                  type={type}

                  name="password"
                  class="border-0 form-control"
                  placeholder="Enter your Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <span class="flex justify-around items-center" onClick={handleToggle}>
                  <Icon class="absolute mr-10" icon={icon} size={20} />
                </span>
              </div>
              <p class="text-danger">{errPas}</p>
              <p class="text-danger">{error}</p>


              <center><button class="bg-success w-100 h-50 py-2 my-2 text-white border-0 " onClick={login}>Submit</button></center>
            </form>
          </div>
        </div>
      </body>
    </header>
  );
}

export default Login;
