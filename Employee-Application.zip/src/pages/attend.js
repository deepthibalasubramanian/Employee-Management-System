import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import '../assets/employeedstyle.css';
import Login from "./employeelogin";
import image from "../assets/profile.png"
import attendance from "../assets/attendance.png";
import { FaSignOutAlt } from "react-icons/fa";
import month from "../assets/month.png";
import week from "../assets/week.png";
import day from "../assets/day.png";
import '../css/bootstrap.min.css';
import Emppage from './emppage';
import TopBar from './topbar.js';
import SideBar from './sidebar.js';
import ls from 'local-storage';
import API from "./base_services/service";
import Pagination from 'reactjs-hooks-pagination';
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';
import Loading from './loading';

const pageLimit = 5;
function Attend() {

    const data = ls.get('userDetails');
    const [empInfo, setEmpInfo] = useState("");
    const [AadInfo, setAtdInfo] = useState("");
    const [totalRecords, setTotalRecords] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [loading, setLoading] = useState(true);
    useEffect(() => {
        empList();
        AtdList();
    }, [data.employees_id])
    const empList = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("employeeview/condition", request).then((response) => {
            setEmpInfo(response.data?.data[0])
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    const AtdList = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("emp_atenList/condition", request).then((response) => {
            setAtdInfo(response.data?.data);
            setTotalRecords(response.data?.data.length)
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    const onClick = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("addemployeesintime/add", request).then((response) => {
            if (response.data.success == true) {
                empList();
                AtdList();
            }

        })
    }
    


    const Login = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("loginAdd/update", request).then((response) => {
            empList();
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }

    const handleSubmit = () => {
        onClick();
        Login();
    }
    const onClick2 = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("addemployeesouttime/update", request).then((response) => {
            if (response.data.success == true) {
                empList();
                AtdList();
            }

        })
    }
    

    const Logout = () => {

        let request = {
            employees_id: data.employees_id
        }

        API.post("logoutAdd/update", request).then((response) => {
            empList();
            setTimeout(() => {
                setLoading(false);
            }, 1000)

        })
    }
    const handleSubmit2 = () => {
        onClick2();
        Logout();
    }

    

    return (
        <body>
            <TopBar data={data}/>
            <SideBar />
            <div class="main">
                <h2>Attendance</h2>
                {loading ? <Loading /> :
                    <div class="row">
                        <div class="col-6 p-5 d-grid ">
                            <center>
                                <img src={image} height="200px" width="200px" class="rounded-4" />
                                <br />
                                <div class="d-flex bcontainer justify-content-around ">
                                    {empInfo.in_out == 1 ?
                                    <button class="text-white h-25 bg-success imp w-100" onClick={handleSubmit2}>Logout</button>:
                                    <button class="text-white h-25 bg-success imp w-100" onClick={handleSubmit}>Login</button>}
                                </div>
                            </center>

                        </div>
                        <div class="col-6" >

                            <div class="c1 shadow px-2 py-2" >
                                <div class="d-flex flex-wrap justify-content-between mx-1">
                                    <h6>Employee ID</h6>
                                    <h6>{empInfo.employees_id}</h6>
                                </div>
                                <hr />
                                <div class="d-flex flex-wrap justify-content-between mx-1 ">
                                    <h6>Employee name</h6>
                                    <h6>{empInfo.employeeName}</h6>
                                </div>
                                <hr />


                                <div class="d-flex flex-wrap justify-content-between mx-1 ">
                                    <h6>Department</h6>
                                    <h6>{empInfo.department}</h6>
                                </div>
                                <hr />
                                <div class="d-flex flex-wrap justify-content-between mx-1 ">
                                    <h6>Email id</h6>
                                    <h6>{empInfo.email}</h6>
                                </div>
                                <hr />
                                <div class="d-flex flex-wrap justify-content-between mx-1 ">
                                    <h6>Mobile No.</h6>
                                    <h6>{empInfo.phone_number}</h6>
                                </div>
                                <hr />
                                <div class="d-flex flex-wrap justify-content-between mx-1 ">
                                    <h6>Date of Joining</h6>
                                    <h6>{empInfo.createdDate}</h6>
                                </div>

                            </div>

                        </div>
                    </div>}
                    {loading ? < Loading /> :
                    <table className=" bg-white shadow wh100 text-black border-0 table3 mt-3 " id="mytable" >
                        <thead>
                            <tr class="bb text-black">

                                <th class="text-start text-black border-0 th3">
                                ID
                                </th>
                                <th class="text-start text-black border-0 th3">
                                Date
                                </th>
                                <th class="text-start text-black border-0 th3">
                                Login Time
                                </th>

                                <th class="text-start text-black border-0 th3">Logout Time</th>

                            </tr>
                        </thead>
                        <tbody>
                            {AadInfo.length > 0 ? AadInfo.sort((a, b) => b.leave_id - a.leave_id).slice(currentPage == 1 ? 0 : (currentPage - 1) * pageLimit, (currentPage == 1 ? currentPage * pageLimit : currentPage * pageLimit))
                                .map((AadInfo, index) =>
                                    <tr className=" bb text-black" key={index}>
                                        <td className="text-black border-0 td3">{index + 1}</td>
                                        <td className="text-black border-0 td3">{AadInfo.createdDate}</td>
                                        <td className="text-black border-0 td3">{AadInfo.in_time}</td>
                                        <td className="text-black border-0 td3">{AadInfo.out_time}</td>
                                    </tr>

                                ) : <tr><td colSpan="20" className='text-center'  ><p className="nodata-found">No Data Found</p> </td></tr>}
                        </tbody>
                    </table>}
                <ul className="pagination">
                    <Pagination className=""
                        totalRecords={totalRecords}
                        pageLimit={pageLimit}
                        pageRangeDisplayed={1}
                        onChangePage={setCurrentPage}
                    />
                </ul>
            </div>
        </body>
    )
}

export default Attend;