import React from 'react';
import './overall.css';
import './css/bootstrap.min.css';
import { useNavigate, useLocation } from 'react-router-dom';
import {FaSignOutAlt} from 'react-icons/fa';
function Sidebar() {

    const navigate = useNavigate();
    const location = useLocation();

    return (
        <body>

            <div className="sidenav shadow">
                {/* <a href="./dashboard" class="sidenavi">Dashboard</a>
                <a href="./adminpage" class="sidenavi">Admins</a>
                <a href="./employeepage" class="sidenavi">Employees</a>
                <a href="./attendance" class="sidenavi">Attendance</a>
                <a href="./leaverequest" class="sidenavi">Leave Requests</a> */}
                <div className={location.pathname === '/dashboard' ? 'active' : ''} >
                    <a onClick={() => navigate('/dashboard')} className="sidenavi"><i className='fa-solid fa-gauge'></i><span>&ensp;Dashboard</span></a>
                </div>
                <div className={location.pathname === '/adminpage' ? 'active' : ''}>
                    <a onClick={() => navigate('/adminpage')} className="sidenavi"><i className='fa-solid fa-user'></i><span>&ensp;Admins</span></a>
                </div>
                <div className={location.pathname === '/employeepage' ? 'active' : ''}>
                    <a onClick={() => navigate('/employeepage')} className="sidenavi"><i className='fa-solid fa-users'></i><span>Employees</span></a>
                </div>
                <div className={location.pathname === '/attendance' ? 'active' : ''}>
                    <a onClick={() => navigate('/attendance')} className="sidenavi"><i className='fa-solid fa-clipboard-user'></i><span>&ensp;Attendance</span></a>
                </div>
                <div className={location.pathname === '/leaverequest' ? 'active' : ''}>
                    <a onClick={() => navigate('/leaverequest')} className="sidenavi"><i className='fa-solid fa-person-walking-arrow-right'></i><span>Leave Requests</span></a>
                </div>
            </div>
        </body>
    )
}
export default Sidebar;