import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import '../css/bootstrap.min.css';

function SideBar() {

    const navigate = useNavigate();
    const location = useLocation();

    return (
        <div class="sidenav shadow">
            <div className={location.pathname === '/employeedashboard' ? 'active' : ''} >
                <a onClick={() => navigate('/employeedashboard')} className="links"><i className="fa-solid fa-gauge"></i><span>&ensp;Dashboard</span></a>
            </div>
            <div className={location.pathname === '/empprofile' ? 'active' : ''} >
                <a onClick={() => navigate('/empprofile')} className="links"><i className="fa-solid fa-user"></i><span>&ensp;Profile</span></a>
            </div>
            <div className={location.pathname === '/attend' ? 'active' : ''} >
                <a onClick={() => navigate('/attend')} className="links"><i className="fa-solid fa-clipboard-user"></i><span>&ensp;Attendance</span></a>
            </div>
            <div className={location.pathname === '/emppage' ? 'active' : ''} >
                <a onClick={() => navigate('/emppage')} className="links"><i class="fa-solid fa-person-walking-arrow-right"></i><span>Leave Info</span></a>
            </div>
             {/* <a href="./employeedashboard" class="links">Dashboard</a>
            <a href="./empprofile" class="links">Profile</a>
            <a href="./attend" class="links">Attendance</a>
            <a href="./emppage" class="links">Leave Info</a> */}
        </div> 
    )
}
export default SideBar;
