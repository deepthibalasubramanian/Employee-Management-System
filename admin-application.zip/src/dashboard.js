import React, {useState, useEffect} from 'react';
import ReactDOM from 'react-dom/client';
import './overall.css';
import Login from "./loginpage";
import image from "./profile.png"
import attendance from "./attendance.png";
import month from "./month.png";
import week from "./week.png";
import day from "./day.png";
import adm from "./admin.png"
import emp from "./employee.png"
import './css/bootstrap.min.css';
import Topbar from './topbar';
import Sidebar from './sidebar';
import pending from './leavepending.png';
import lr from './leave-request.png';
import la from './leaveapproved.png';
import lrej from './leaverejected.png';
import {
    Link,
    Routes,
    Route,
    useNavigate,
} from 'react-router-dom';
import Loading from './loading';
import API from './baseServices/services'

function Dashboard() {
    const [dashboardInfo, setDashboardInfo] = useState("");
    const [loading, setLoading] = useState(true);


    useEffect(() => {
        DashbordCount()
    }, [])

    const DashbordCount = () => {

        API.post("admin_dashboard_count/condition").then((response) => {
            setDashboardInfo(response.data?.data[0])
            setTimeout(() => {
            setLoading(false);
            }, 1000)

        })
    }

    return (
        <body>
            <Topbar />
            <Sidebar />

            <div class="main">
                <h2>Dashboard</h2>
                {loading ? <Loading /> :
                <div class="d-flex flex-wrap ">
                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">
                        <h6>Total Admins</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.adminCount}</h1>
                            <img src={adm} class="wh" />
                        </div>
                    </div>
                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">
                        <h6>Total Employees</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.employeesCount}</h1>
                            <img src={emp} class="wh" />
                        </div>
                    </div>
                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">
                        <h6>Total Attendance</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.attendanceCount}</h1>
                            <img src={attendance} class="wh" />
                        </div>
                    </div>

                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">

                        <h6>Total Leave Requests</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leaveCount}</h1>
                            <img src={lr} class="wh" />
                        </div>
                    </div>
                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">

                        <h6>Approved Leave Requests</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leaveApprovedcount}</h1>
                            <img src={la} class="wh" />
                        </div>
                    </div>
                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">

                        <h6>Pending Leave Requests</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leavePendingcount}</h1>
                            <img src={pending} class="wh" />
                        </div>
                    </div>
                    <div class="card card1 h-25 border-2 mt-3 p-2 mx-2 mb-2 shadow">

                        <h6>Rejected Leave Requests</h6>
                        <div class="d-flex justify-content-between">
                            <h1>{dashboardInfo.leaveRejectedcount}</h1>
                            <img src={lrej} class="wh" />
                        </div>
                    </div>

                </div>}
            </div>

        </body>
    )
}

export default Dashboard;