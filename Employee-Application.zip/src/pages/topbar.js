import React from 'react';
import ReactDOM from 'react-dom/client';
import '../assets/employeedstyle.css';
import Login from "./employeelogin";
import image from "../assets/profile.png"
import attendance from "../assets/attendance.png";
import { FaSignOutAlt } from "react-icons/fa";
import month from "../assets/month.png";
import week from "../assets/week.png";
import day from "../assets/day.png";
import '../css/bootstrap.min.css';
import Emppage from './emppage';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import LogoutRequest from './modal.js';
import {
    Link,
    Routes,
    Route,
    useNavigate,
  } from 'react-router-dom';

function TopBar(props){
    const {data} = props
    console.log(data, "datatop");

    return(
        <div class=" topbar shadow d-flex justify-content-between px-2 bg-white">
            <h2 class="employeeh2 mt-auto mb-auto" ><b><i>LOGO</i></b></h2>
            
            <div class="d-flex">
                <h6 class="employeeh6">Welcome, {data.first_name} {data.last_name} <img src={image} height="25px" width="25px" /></h6>
                <LogoutRequest />
            </div>
            </div>
    )
}
export default TopBar;
